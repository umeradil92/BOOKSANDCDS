<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha384-vk5WoKIaW/vJyUAd9n/wmopsmNhiy+L2Z+SBxGYnUkunIxVxAv/UtMOhba/xskxh" crossorigin="anonymous"></script>
	<script src="js/jquery-accordion.js"></script>
	<script>
		$(".faq").accordion({
            questionClass: '.header',
            answerClass: '.content',
            itemClass: '.faqitem'
		});
	</script>
    <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

       
       
       <footer class="footer bg-white" style="width: 100%;">
            <div class="container">
                <div class="footer-middle">
                    <div class="row">
                        <div class=" col-sm-5 col-xl-5">
                            <a href="index.php">
                                <img src="images/logo3.png" alt="footer Logo"  style="width:400px;height:150px">
                            </a>
                            <p class="p-intro" style="font-family:cursive">We sell different types of books of different publications of stories, school related text books, note books, essay writing books, some of books for the competitions like General Knowledge, Essay Writing, and also novels, books to improve vocabulary, for learning other languages,etc and also we sell some of the book related materials like covers, pens, pencils, Files, etc.</p>

                        </div>
                        <div class="col-xl-7">
                            <div class="row row-sm" style="border-left:2px solid gray;height:270px;padding-left:40px;">
                                <div class="col-sm-6 col-xl-6">
                                    <div class="widget" style="border-right:2px solid gray;width:250px;height:115px;font-family:cursive">
                                        <h4 class="widget-title" style="font-family:cursive;letter-spacing:3px;">Account</h4>
                                        <ul class="links">
                                            <li><a href="#" style="font-family:cursive">My Account</a></li>
                                            <li><a href="cart.php" style="font-family:cursive">Track Your Order</a></li>
                                            <li><a href="#" style="font-family:cursive">Payment Methods</a></li>
                                            <li><a href="faqs.php" style="font-family:cursive">FAQs</a></li>
                                        </ul>
                                    </div><!-- End .widget -->
                                </div>
                                <div class="col-sm-6 col-xl-6">
                                    <div class="widget">
                                        <h4 class="widget-title" style="font-family:cursive;letter-spacing:3px;">About</h4>
                                        <ul class="links">
                                            <li><a href="about.php" style="font-family:cursive">About Us</a></li>
                                            <li><a href="#" style="font-family:cursive">Site Map</a></li>
                                        </ul>
                                    </div><!-- End .widget -->
                                </div>
                                <div class="contact">
                                    <div class="contact-widget" style="margin-right:30px">
                                        <h4 class="widget-title" style="font-family:cursive"> questions? </h4>
                                        <a href="#" style="font-family:cursive"> 021-2223331 </a>
                                    </div>
                                    <div class="contact-widget">
                                        <h4 class="widget-title" style="font-family:cursive">payment methods</h4>
                                        <img src="images/payments_logo.jpg">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom">
                    <p class="footer-copyright" style="font-family:cursive;font-weight:bold;letter-spacing:4px;">
                    Shradha Book Store. &copy;  2020.  All Rights Reserved</p>
                    <div class="social-icons">
                        <a href="www.facebook.com/Shradha Book Store" target="_blank" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                        <a href="www.twitter.com/Shradha Book Store" target="_blank" class="social-icon"><i class="fab fa-twitter"></i></a>
                        <a href="www.linkedin.com/Shradha Book Store" target="_blank" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
                    </div><!-- End .social-icons -->
                </div>
            </div>
        </footer><!-- End .footer -->
    </div><!-- End .page-wrapper -->

    <div class="mobile-menu-overlay"></div><!-- End .mobil-menu-overlay -->

    <div class="mobile-menu-container">
        <div class="mobile-menu-wrapper">
            <span class="mobile-menu-close"><i class="porto-icon-retweet"></i></span>
            <nav class="mobile-nav">
                <ul class="mobile-menu">
                    <li class="active"><a href="index.php" style="font-family:cursive">Home</a></li>
                    <li>
                                <a href="#" class="sf-with-ul" style="font-family:cursive">Products</a>
                                <ul>
                                    <li><a href="#" style="font-family:cursive">Books</a></li>
                                    <li><a href="#" style="font-family:cursive">CDs</a></li>
                                    <li><a href="#" style="font-family:cursive">DvDs</a></li>
                                    <li><a href="#" style="font-family:cursive">Magazines</a></li>
                                    <li><a href="#" style="font-family:cursive">Files</a></li>
                                    <li><a href="#" style="font-family:cursive">Pen</a></li>
                                    <li><a href="#" style="font-family:cursive">Pencil</a></li>
                                    <li><a href="#" style="font-family:cursive">Paper</a></li>                                    
                                </ul>
                            </li>
                    <li>
                        
                         <li><a href="#" style="font-family:cursive">Track Order</a></li>
                                    <li><a href="about.php" style="font-family:cursive">About Us</a></li>
                                    <li><a href="contact.php" style="font-family:cursive">Contact Us</a></li>
                                    <li><a href="#" style="font-family:cursive">Feedback</a></li>
                                    <li><a href="faqs.php" style="font-family:cursive">FAQs</a></li>
                    </li>                                        
                </ul>
            </nav><!-- End .mobile-nav -->

            <div class="social-icons">
                <a href="#" class="social-icon" target="_blank"><i class="porto-icon-facebook"></i></a>
                <a href="#" class="social-icon" target="_blank"><i class="porto-icon-twitter"></i></a>
                <a href="#" class="social-icon" target="_blank"><i class="porto-icon-instagram"></i></a>
            </div><!-- End .social-icons -->
        </div><!-- End .mobile-menu-wrapper -->
    </div><!-- End .mobile-menu-container -->
    <!-- Add Cart Modal -->
    <div class="modal fade" id="addCartModal" tabindex="-1" role="dialog" aria-labelledby="addCartModal" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-body add-cart-box text-center">
            <p style="font-family:cursive">You've just added this product to the<br>cart:</p>
            <h4 id="productTitle"></h4>
            <img src="#" id="productImage" width="100" height="100" alt="adding cart image">
            <div class="btn-actions">
                <a href="cart.php"><button class="btn-primary" style="font-family:cursive">Go to cart page</button></a>
                <a href="#"><button class="btn-primary" data-dismiss="modal" style="font-family:cursive">Continue</button></a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <a id="scroll-top" href="#top" title="Top" role="button"><i class="porto-icon-angle-up"></i></a>

    <!-- Plugins JS File -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/plugins.min.js"></script>
    <script src="js/jquery.countdown/jquery.countdown.min.js"></script>

    <!-- Main JS File -->
    <script src="js/main_init.min.js"></script>
    <script src="js/main.js"></script>
</body>

<!-- Mirrored from portotheme.com/html/porto_ecommerce/demo_27/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 22 Sep 2020 13:30:11 GMT -->
</html>