<!DOCTYPE html>
<html lang="en">

<head>  
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Shradha General Book Stores</title>

    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="Porto - Bootstrap eCommerce Template">
    <meta name="author" content="SW-THEMES">
        
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="images/logo3.png">

    <!-- jquery -->
  <script
  src="https://code.jquery.com/jquery-3.5.1.js"
  integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc="
  crossorigin="anonymous"></script>
 
    <script type="text/javascript">
        WebFontConfig = {
            google: { families: [ 'Open+Sans:300,400,600,700,800','Poppins:300,400,500,600,700' ] }
        };
        (function(d) {
            var wf = d.createElement('script'), s = d.scripts[0];
            wf.src = 'js/webfont.js';
            wf.async = true;
            s.parentNode.insertBefore(wf, s);
        })(document);
    </script>
    
    <!-- Plugins CSS File -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Main CSS File -->
    <link rel="stylesheet" href="css/style.min.css">
    <link rel="stylesheet" href="vendor/simple-line-icons/css/simple-line-icons.min.css">
    <link rel="stylesheet" href="vendor/fontawesome-free/css/all.min.css">
    <style>
    </style>
</head>
<body>
	<header class="header">
            <div class="header-top">
                <div class="col-md-6">
                    <i class="porto-icon-shipping"></i>
                    <h2 style="font-family:cursive">Free Shipping on Orders less than 3kms</h2>
                </div>
                <div class="col-md-6 header-top-center">
                    <i class="porto-icon-money"></i>
                    <h2 style="font-family:cursive">Up to 40% OFF on Selected Items</h2>
                </div>
                
            </div><!-- End .header-top -->

            <div class="header-bottom sticky-header">
                <div class="header-left">
                    <button class="mobile-menu-toggler" type="button">
                        <i class="icon-menu"></i>
                    </button>
                    <a href="index.php" class="logo">
                        <img src="images/logo3.png" alt="Porto Logo" style="max-height: 80px">
                            
                        
                    </a>
                    <nav class="main-nav">
                        <ul class="menu sf-arrows">
                            <li class="active"><a href="index.php" style="font-family:cursive">Home</a></li>
                            <li><a href="#" class="sf-with-ul" style="font-family:cursive">Products</a>
                                <ul>
                                    <li><a href="books.php" style="font-family:cursive">Books</a></li>
                                    <li><a href="CDS.php" style="font-family:cursive">CDs</a></li>
                                    <li><a href="DVDS.php" style="font-family:cursive">DvDs</a></li>
                                    <li><a href="magazines.php" style="font-family:cursive">Magazines</a></li>
                                    <li><a href="files.php" style="font-family:cursive">Files</a></li>
                                    <li><a href="pen.php" style="font-family:cursive">Pen</a></li>
                                    <li><a href="pencil.php" style="font-family:cursive">Pencil</a></li>
                                    <li><a href="paper.php" style="font-family:cursive">Paper</a></li>                                    
                                </ul>
                            </li>
                            <li><a href="orders.php" style="font-family:cursive">Track Order</a></li>
                            <li><a href="about.php" style="font-family:cursive">About Us</a></li>
                            <li><a href="contact.php" style="font-family:cursive">Contact Us</a></li>
                            <li><a href="feedback.php" style="font-family:cursive">Feedback</a></li>
                            <li><a href="faqs.php" style="font-family:cursive">FAQs</a></li>
                        </ul>
                    </nav>
                </div><!-- End .header-left -->
                <div class="horizontal_bar"></div>
                <div class="header-right">                 
                    <div class="horizontal_bar"></div>
                    <a href="login.php">
                        <div class="header-user" style="margin-left: 230px">
                            <?php
                            if(isset($_SESSION['id'])){

                            ?>
                            <span>Hello!</span>
                            <p> <?php echo $_SESSION['user'] ?? null ?> </p>
                            <a href="logout.php"> | Logout</a?
                            <?php
                            }
                            else{
                            ?>
                            <i class="porto-icon-user-2"></i>
                            <?php } ?>
                            <div class="header-userinfo">
                           
                            </div>
                        </div>
                    </a>
                    <div class="dropdown cart-dropdown">
                        <a href="#" class="dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static">
                            <a href="cart.php">
                            <i class="minicart-icon"></i>
                            </a>
                        </a>

                      
                    </div><!-- End .dropdown -->
                </div><!-- End .header-right -->
            </div><!-- End .header-bottom -->
        </header><!-- End .header -->