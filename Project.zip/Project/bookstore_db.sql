-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2020 at 08:15 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_categories`
--

CREATE TABLE `tb_categories` (
  `id` int(11) NOT NULL,
  `category_id` varchar(50) NOT NULL,
  `category_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_categories`
--

INSERT INTO `tb_categories` (`id`, `category_id`, `category_name`) VALUES
(6, 'O9', 'Books'),
(7, 'Z6', 'CDS'),
(8, 'K2', 'DVDS'),
(9, 'X1', 'Magazines'),
(10, 'D7', 'Files'),
(11, 'L8', 'Pens'),
(12, 'S4', 'Pencils'),
(13, 'T7', 'Papers');

-- --------------------------------------------------------

--
-- Table structure for table `tb_checkout`
--

CREATE TABLE `tb_checkout` (
  `id` int(11) NOT NULL,
  `checkout_orderno` bigint(20) NOT NULL,
  `checkout_fk_user` int(11) NOT NULL,
  `checkout_add_country` varchar(50) NOT NULL,
  `checkout_add_city` varchar(50) NOT NULL,
  `checkout_add_street1` varchar(255) NOT NULL,
  `checkout_add_street2` varchar(255) DEFAULT NULL,
  `chectout_add_zipcode` varchar(50) NOT NULL,
  `checkout_add_phoneno` varchar(50) NOT NULL,
  `checkout_paymentmethod` varchar(50) NOT NULL,
  `checkout_price` decimal(15,2) NOT NULL,
  `checkout_fk_product` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_checkout`
--

INSERT INTO `tb_checkout` (`id`, `checkout_orderno`, `checkout_fk_user`, `checkout_add_country`, `checkout_add_city`, `checkout_add_street1`, `checkout_add_street2`, `chectout_add_zipcode`, `checkout_add_phoneno`, `checkout_paymentmethod`, `checkout_price`, `checkout_fk_product`) VALUES
(10, 45738552, 3, 'TEST', 'TEST', 'TEST', 'TEST', 'TEST', 'TEST', 'Cash on Delivery', '17.00', 7);

-- --------------------------------------------------------

--
-- Table structure for table `tb_faq`
--

CREATE TABLE `tb_faq` (
  `id` int(11) NOT NULL,
  `faq_ques` varchar(255) NOT NULL,
  `faq_ans` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_faq`
--

INSERT INTO `tb_faq` (`id`, `faq_ques`, `faq_ans`) VALUES
(6, 'How many days will it take to deliver the order? ', 'Depends on the Order, Quantity and Stock and as well on the payment type chosen, as if the payment option chosen is payment before delivery, then the order will only be dispatched after the receipt of the payment.'),
(7, 'What if the order delivered is not in proper condition? ', 'If the order delivered is improper, it will be replace with the other'),
(8, 'Can an Order be cancelled? If yes, will there be any charges? ', 'Yes, but if cancelled with in 24 Hrs. there will be no charges, but if cancelled after 24 Hrs. and if the Order is being dispatched the Delivery charges for the to and fro is to be bared by the one who has ordered.'),
(9, 'How can the payment be made? ', 'You can pay online or you can select cash on delivery.');

-- --------------------------------------------------------

--
-- Table structure for table `tb_feedback`
--

CREATE TABLE `tb_feedback` (
  `id` int(11) NOT NULL,
  `feedback_fk_user` int(11) NOT NULL,
  `feedback_fk_checkout` int(11) DEFAULT NULL,
  `feedback_text` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tb_onlinepayment`
--

CREATE TABLE `tb_onlinepayment` (
  `id` int(11) NOT NULL,
  `onlinepayment_cardnumber` varchar(16) NOT NULL,
  `onlinepayment_expiry` varchar(50) NOT NULL,
  `onlinepayment_cvv` int(4) NOT NULL,
  `onlinepayment_fk_users` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_onlinepayment`
--

INSERT INTO `tb_onlinepayment` (`id`, `onlinepayment_cardnumber`, `onlinepayment_expiry`, `onlinepayment_cvv`, `onlinepayment_fk_users`) VALUES
(4, '', '', 0, 3),
(5, '', '', 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_products`
--

CREATE TABLE `tb_products` (
  `id` int(11) NOT NULL,
  `products_id` varchar(5) NOT NULL,
  `products_name` varchar(50) NOT NULL,
  `products_image` varchar(50) NOT NULL,
  `products_manufacturer` varchar(50) NOT NULL,
  `products_price` decimal(15,2) NOT NULL,
  `products_type` tinyint(4) NOT NULL COMMENT '0 for null | 1 for readable | 2 for reweritable',
  `products_status` tinyint(4) NOT NULL COMMENT '0 is for inactive | 1 is for active',
  `products_description` varchar(255) NOT NULL,
  `products_stock` int(11) NOT NULL,
  `products_fk_category` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_products`
--

INSERT INTO `tb_products` (`id`, `products_id`, `products_name`, `products_image`, `products_manufacturer`, `products_price`, `products_type`, `products_status`, `products_description`, `products_stock`, `products_fk_category`) VALUES
(7, 'BW979', 'The End Of Loneliness', 'book1.jpg', 'Benedict Wells', '15.00', 0, 1, 'From internationally bestselling author Benedict Wells, a sweeping novel of love and loss, and of the lives we never get to live.', 2, 6),
(8, 'CD908', 'Sherlock Holmes', 'book2.jpg', 'Conan Doyle', '15.00', 0, 1, 'His first Sherlock Holmes story, “A Study in Scarlet,” was published in Beeton\'s Christmas Annual in 1887. ', 2, 6),
(9, 'RH693', 'Stranger in a Strange Land', 'book3.jpg', 'Robert Heinlein', '20.00', 0, 1, 'Stranger in a Strange Land is a 1961 science fiction novel by American author Robert A. Heinlein.', 5, 6),
(10, 'HL746', 'To Kill A Mockingbird', 'book4.jpg', 'Harper Lee', '16.00', 0, 1, 'To Kill a Mockingbird is a novel by Harper Lee published in 1960.', 10, 6),
(11, 'GO185', 'Nineteen Eighty Four', 'book5.jpg', 'George Owell', '10.00', 0, 1, 'Nineteen Eighty Four is a novel by George Owell published in 1984. Instantly successful.', 10, 6),
(12, 'JR431', 'Harry Potter And The Philospher Stone', 'book6.jpg', 'J.K Rowling', '8.00', 0, 1, 'Harry Potter is a 1961 science fiction novel by American author Robert A. Heinlein.', 10, 6),
(13, 'S995', 'CD', 'CD1.jpg', 'Sony', '3.00', 1, 1, 'This is a Readable CD. Its size is 500mb.', 10, 7),
(14, 'S308', 'CD', 'CD2.jpg', 'Sony', '4.00', 2, 1, 'This is a Rewriteable CD. Its size is 1000mb.', 10, 7),
(15, 'S302', 'CD', 'CD3.jpg', 'Sony', '3.00', 1, 1, 'This is a Readable CD. Its size is 500mb.', 10, 7),
(16, 'V254', 'CD', 'CD4.jpg', 'Verbatim', '3.00', 2, 1, 'This is a Rewriteable CD. Its size is 2000mb.', 10, 7),
(17, 'M689', 'CD', 'CD5.jpg', 'Maxell', '2.00', 2, 1, 'This is a Rewriteable CD. Its size is 2000mb.', 10, 7),
(18, 'S309', 'CD', 'CD6.jpg', 'Staples', '4.00', 2, 1, 'This is a Rewriteable CD. Its size is 700mb.', 10, 7),
(19, 'V721', 'DVD', 'DVD1.jpg', 'Verbatim', '4.00', 2, 1, 'This is a Rewriteable DVD. Its size is 2000mb.', 10, 8),
(20, 'S544', 'DVD', 'DVD2.jpeg', 'Sony', '3.00', 2, 1, 'This is a Rewriteable DVD. Its size is 1000mb.', 10, 8),
(21, 'K698', 'DVD', 'DVD3.jpg', 'Kodak', '4.00', 1, 1, 'This is a Readable DVD. Its size is 2000mb', 10, 8),
(22, 'R550', 'DVD', 'DVD4.jpg', 'Ridata', '3.00', 1, 1, 'This is a Readable DVD. Its size is 500mb.', 10, 8),
(23, 'R277', 'DVD', 'DVD5.jpg', 'Ronc', '4.00', 2, 1, 'This is a Rewriteable DVD. Its size is 2000mb.', 10, 8),
(24, 'M247', 'DVD', 'DVD6.jpg', 'Maxell', '3.00', 2, 1, 'This is a Rewriteable DVD. Its size is 2000mb.', 10, 8),
(25, 'JG370', 'Mental Floss', 'mg1.jpg', 'Jain Goodail', '6.00', 0, 1, 'If you’re the kind of person who asks yourself these questions, you’ll love Mental Floss.', 10, 9),
(26, 'JG221', 'Fast Company', 'mg2.jpg', 'Jain Goodail', '4.00', 0, 1, 'Fast Company is one of the more approachable (easy-to-read) magazines about business and companies.', 10, 9),
(27, 'MC294', 'Reader’s Digest', 'mg3.jpg', 'Michelle Crouch', '5.00', 0, 1, 'Reader’s Digest is not actually about books or reading. Instead, it is about people', 10, 9),
(28, 'JR641', 'Cricket and Cicada', 'mg4.jpg', 'J.K Rowling', '3.00', 0, 1, 'Cricket and Cicada are literary magazines aimed at teenagers.', 10, 9),
(29, 'RB274', 'TIME and TIME For Kids', 'mg5.jpg', 'Ruth Badger Ginsburg', '7.00', 0, 1, 'TIME is one of the most well-known magazines in the world.', 10, 9),
(30, 'HL131', 'Sunset', 'mg6.jpg', 'Harper Lee', '4.00', 0, 1, 'Take a trip to a new place without even leaving your chair. ', 10, 9),
(31, 'SB164', 'File', 'file1.jpg', 'Shradha Book Store', '2.00', 0, 1, 'This is a plastic file.', 10, 10),
(32, 'SB150', 'File', 'file2.jpg', 'Shradha Book Store', '2.00', 0, 1, 'This is a plastic file.', 10, 10),
(33, 'SB181', 'File', 'file3.jpg', 'Shradha Book Store', '1.00', 0, 1, 'This is a paper file.', 10, 10),
(34, 'SB127', 'File', 'file4.jpg', 'Shradha Book Store', '4.00', 0, 1, 'This is a plastic file.', 10, 10),
(35, 'SB423', 'File', 'file5.jpg', 'Shradha Book Store', '2.00', 0, 1, 'This is a paper file.', 10, 10),
(36, 'SB974', 'File', 'file6.jpg', 'Shradha Book Store', '1.00', 0, 1, 'This is a paper file.', 10, 10),
(37, 'C939', 'Pen', 'pen1.jpg', 'Clipper', '2.00', 0, 1, 'This is a ball pen.', 10, 11),
(38, 'D650', 'Pen', 'pen2.jpg', 'Dollar', '4.00', 0, 1, 'This is an ink pen.', 10, 11),
(39, 'S984', 'Pen', 'pen3.jpg', 'Signature', '2.00', 0, 1, 'This is a ball pen.', 10, 11),
(40, 'ZG790', 'Pen', 'pen4.jpg', 'Z Gaopo', '4.00', 0, 1, 'This is a gel pen.', 10, 11),
(41, 'S865', 'Pen', 'pen5.jpg', 'Shichen', '3.00', 0, 1, 'This is an ink pen.', 10, 11),
(42, 'S209', 'Pen', 'pen6.jpg', 'Siraj', '3.00', 0, 1, 'This is an ink pen.', 10, 11),
(43, 'D277', 'pencil', 'pencil1.jpg', 'Dollar', '2.00', 0, 1, 'This is a pencil.', 10, 12),
(44, 'D932', 'pencil', 'pencil2.jpg', 'Dollar', '6.00', 0, 1, 'These are color pencils.', 10, 12),
(45, 'P928', 'pencil', 'pencil3.jpg', 'Piano', '2.00', 0, 1, 'This is a pencil.', 10, 12),
(46, 'D183', 'pencil', 'pencil4.jpg', 'Dux', '3.00', 0, 1, 'This is a pencil.', 10, 12),
(47, 'B671', 'pencil', 'pencil5.jpg', 'Bic', '2.00', 0, 1, 'This is a pencil.', 10, 12),
(48, 'D535', 'pencil', 'pencil6.jpg', 'Dollar', '5.00', 0, 1, 'These are color pencils.', 10, 12),
(49, 'SB475', 'Paper', 'paper1.jpg', 'Shradha Book Store', '2.00', 0, 1, 'These are colored papers.', 10, 13),
(50, 'DA325', 'Paper', 'paper2.jpg', 'Double A', '1.00', 0, 1, 'These are A4 sized papers.', 10, 13),
(51, 'G669', 'Paper', 'paper3.jpg', 'Green', '2.00', 0, 1, 'These are A4 sized papers.', 10, 13),
(52, 'PO266', 'Paper', 'paper4.jpg', 'Paper One', '2.00', 0, 1, 'These are A4 sized papers.', 10, 13),
(53, 'SB818', 'Paper', 'paper5.jpg', 'Shradha Book Store', '4.00', 0, 1, 'These are colored chart papers.', 10, 13),
(54, 'SB183', 'Paper', 'paper6.jpg', 'Shradha Book Store', '5.00', 0, 1, 'These are glossy papers.', 10, 13);

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE `tb_users` (
  `id` int(11) NOT NULL,
  `users_fname` varchar(50) NOT NULL,
  `users_lname` varchar(50) NOT NULL,
  `users_email` varchar(50) NOT NULL,
  `users_password` varchar(255) NOT NULL,
  `users_type` tinyint(4) NOT NULL COMMENT '0 for admin | 1 for users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`id`, `users_fname`, `users_lname`, `users_email`, `users_password`, `users_type`) VALUES
(3, 'Muhammad', 'saad', 'msaad2110@gmail.com', '$2y$10$qjeJL6q7xE1Hi4HShwZ7Be9isLtSF9c37.PQDFN8uKcdFr/LfTQ92', 1),
(4, 'Muhammad', 'saad', 'msaad2124@gmail.com', '$2y$10$ZPptq9e/RHyobqPjTUtUbewZ4pDztGfqPKRJP5o2JfVJwJa2LMORq', 0),
(7, 'test', 'test', 'admin@email.com', '$2y$10$lQCml2zQbm27AUx1OhYdVeuky1lf8cTWczODxgrXXisLdB10uUqs2', 0),
(8, 'test', 'test', 'test@email.com', '$2y$10$leefCxIfwRH3p5iBdWeD6utUbW2XfqefcWox7C3QYnedyIhkCgske', 1),
(9, 'sidd', 'jam', 'siddjam@gmail.com', '$2y$10$NAqKmMMdXVX5obwSnLcpNuxWUmwWWbvdxTtB9jva9SmxKMupo5r7e', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_categories`
--
ALTER TABLE `tb_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_checkout`
--
ALTER TABLE `tb_checkout`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `checkout_orderno` (`checkout_orderno`),
  ADD KEY `fk_users` (`checkout_fk_user`),
  ADD KEY `fk_products` (`checkout_fk_product`);

--
-- Indexes for table `tb_faq`
--
ALTER TABLE `tb_faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_feedback`
--
ALTER TABLE `tb_feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `feedback_fk_user` (`feedback_fk_user`),
  ADD KEY `feedback_fk_checkout` (`feedback_fk_checkout`);

--
-- Indexes for table `tb_onlinepayment`
--
ALTER TABLE `tb_onlinepayment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_online_users` (`onlinepayment_fk_users`);

--
-- Indexes for table `tb_products`
--
ALTER TABLE `tb_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_category` (`products_fk_category`);

--
-- Indexes for table `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email` (`users_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_categories`
--
ALTER TABLE `tb_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tb_checkout`
--
ALTER TABLE `tb_checkout`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tb_faq`
--
ALTER TABLE `tb_faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tb_feedback`
--
ALTER TABLE `tb_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_onlinepayment`
--
ALTER TABLE `tb_onlinepayment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_products`
--
ALTER TABLE `tb_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_checkout`
--
ALTER TABLE `tb_checkout`
  ADD CONSTRAINT `fk_products` FOREIGN KEY (`checkout_fk_product`) REFERENCES `tb_products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_users` FOREIGN KEY (`checkout_fk_user`) REFERENCES `tb_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_feedback`
--
ALTER TABLE `tb_feedback`
  ADD CONSTRAINT `feedback_fk_checkout` FOREIGN KEY (`feedback_fk_checkout`) REFERENCES `tb_checkout` (`id`),
  ADD CONSTRAINT `feedback_fk_user` FOREIGN KEY (`feedback_fk_user`) REFERENCES `tb_users` (`id`);

--
-- Constraints for table `tb_onlinepayment`
--
ALTER TABLE `tb_onlinepayment`
  ADD CONSTRAINT `fk_online_users` FOREIGN KEY (`onlinepayment_fk_users`) REFERENCES `tb_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_products`
--
ALTER TABLE `tb_products`
  ADD CONSTRAINT `fk_category` FOREIGN KEY (`products_fk_category`) REFERENCES `tb_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
