<?php
include('include/header.php');
include('DB_connection.php');


$query = mysqli_query($con,"SELECT tb_products.id,`products_name`, `products_image`, `products_price`,`category_name` FROM tb_products JOIN tb_categories WHERE products_status=1 and products_fk_category=10 and products_fk_category=bookstore_db.tb_categories.id");
$path = "admin/uploads/";


?>
    <div class="page-wrapper">
        

        <main class="main">
            <div class="banner banner-cat" style="background-image: url('images/banners/category-banner.jpg');">
                <div class="container">
                    <div class="banner-content">
                        <h3 class="banner-subtitle">BOOK CLUB</h2>
                        <h2 class="banner-title">Summer Reading</h1>
                        <h3 class="banner-foot">The best books for your beach bag</h2>
                    </div><!-- End .banner-content -->
                    <button class="btn">EXPLORE BOOKS<i class="porto-icon-right"></i></button>
                </div>
            </div><!-- End .banner -->
            
            <nav aria-label="breadcrumb" class="breadcrumb-nav">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php" style="font-family:cursive">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page" style="font-family:cursive">products/files</li>
                    </ol>
                </div><!-- End .container -->
            </nav>

            <div class="bg-white pt-35 pb-5">
                <div class="container">
                    <div class="row row-sm">
                        <div class="col-12">
                            <nav class="toolbox">


                                <div class="toolbox-item toolbox-show">
                                </div><!-- End .toolbox-item -->

                                                                    
                                </div><!-- End .layout-modes -->
                            </nav>

                            <div class="product-wrapper">
                                
                                <div class="row row-sm home-products-intro category-grid">
                                    
                                 <?php
                                while($fetch = mysqli_fetch_array($query)){
                                ?>
                                    <div class="col-6 col-sm-4 col-xl-2" style="margin-left:85px;">
                                        <div class="home-product product-default inner-quickview">
                                            <figure>
                                                <a href="product.php?id=<?php echo $fetch['id']?>"><img src="<?php echo $path.$fetch['products_image']?>" style="height: 352px;width: 214px"></a>
                                                
                                          
                                            
                                            </figure>
                                            <div class="product-details">
                                                <div class="category-wrap">
                                                    <h2 class="product-category"><?php echo $fetch['category_name']?></h2>
                                                    <a href="#"><i class="porto-icon-wishlist-2"></i></a>
                                                </div>
                                                <h2 class="product-title">
                                                    <a href="product.php"><?php echo $fetch['products_name']?></a>
                                                </h2>
                                                <!-- End .product-container -->
                                                <div class="price-box">
                                                  
                                                    <span class="product-price"><?php echo $fetch['products_price']?>$</span>
                                                </div><!-- End .price-box -->
                                            </div><!-- End .product-details -->
                                        </div>
                                    </div>

                                <?php }?>
                                    
                                </div>
                            </div>

                            <nav class="toolbox toolbox-pagination" style="align-items : flex-start;">
                                <div class="toolbox-item toolbox-show">
                                </div><!-- End .toolbox-item -->

                                
                            </nav>
                        </div><!-- End .col-lg-9 -->
                    </div>
                </div>
            </div><!-- End .container -->
        </main><!-- End .main -->
<?php
include('include/footer.php');
?>