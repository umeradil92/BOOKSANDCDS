<?php
include('include/header.php');
?>
<div class="container" style="align-items: center;text-align: center;">
<div class="row mx-auto">
	<div class="col-md-6 mx-auto mt-5 mb-5" style="border: 1px solid black">
			<h1>Feedback Form</h1>
		<p>we would like to hear your thoughts, suggestions, concerns or problems
with anything so we can improve!
		</p>
		
		<h2>Feedback Type</h2>
		<form action="#">
    <div class="custom-control custom-radio custom-control-inline">
      <input type="radio" class="custom-control-input" id="customRadio1" name="example1">
      <label class="custom-control-label" for="customRadio1">Comments</label>
    </div>
    <div class="custom-control custom-radio custom-control-inline">
      <input type="radio" class="custom-control-input" id="customRadio2" name="example2">
      <label class="custom-control-label" for="customRadio2">Suggestions</label>
    </div>
<div class="custom-control custom-radio custom-control-inline">
      <input type="radio" class="custom-control-input" id="customRadio3" name="example3">
      <label class="custom-control-label" for="customRadio3">Questions</label>
    </div>
    <p>Describe Your Feedback</p>
    <textarea name="feedback" style="height: 150px;width: 400px;" required=""></textarea><br>
    <p>Name</p>
    <input type="text" name="name" required=""><br>
    <p>Email</p>
    <input type="text" name="email" required=""><br>
    <button type="submit" class="btn btn-primary btn-sm" style="margin-top: 10px;">submit</button>
  </form>
	</div>
</div>
</div>
<?php
include('include/footer.php');
?>