<?php
ob_start();
include('include/header.php');
include('DB_connection.php');
session_start();

?>
    <div class="page-wrapper">
        <main class="main">
            <nav aria-label="breadcrumb" class="breadcrumb-nav mb-2">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                    </ol>
                </div><!-- End .container -->
            </nav>

            <div class="container">
                <ul class="checkout-progress-bar">
                    <li class="active">
                        <span>Shipping</span>
                    </li>
                    <li>
                        <span>Review &amp; Payments</span>
                    </li>
                </ul>
                <div class="row">
                    <div class="col-lg-8">
                        <ul class="checkout-steps">
                            <li>
                                <h2 class="step-title">Shipping Address</h2>

                                <?php if($_SESSION['user'] ?? null){
                                     echo "<br><h3>Welcome back,  " ;
                                     echo $_SESSION['user'];
                                     echo "</h3>";



                                  
                                }
                                
                                else{

                                    echo "<form action='' method='POST'>";
                                    echo "<div class='form-group required-field'>";
                                    echo "   <label>Email Address </label>";
                                    echo "    <div class='form-control-tooltip'>";
                                    echo "        <input type='email' name='email_l' class='form-control' required>";
                                    echo "        <span class='input-tooltip' data-toggle='tooltip' title='We'll send your order confirmation here.' data-placement='right'><i class='porto-icon-question-circle'></i></span>";
                                    echo "    </div>";
                                    echo " </div>";

                                    echo " <div class='form-group required-field'>";
                                    echo "    <label>Password </label>";
                                    echo "    <input name='password_l' type='password' class='form-control' required min='3' max='16'>";
                                    echo " </div>";
                                    
                                    echo " <p>You already have an account with us. Sign in or just register yourself.</p>";
                                    echo "<div class='form-footer'>";
                                    echo " <button type='submit' name='login' class='btn btn-primary'>LOGIN</button>";
                                    echo "    <a href='login.php' class='forget-pass'> Register</a>";
                                    echo "</div>";
                                    echo " </form>";
                                    
                                    if(isset($_POST['login'])){
                                        $email_l=$_POST['email_l'];
                                        $password_l=$_POST['password_l'];
            
                                        $query_l=mysqli_query($con,"SELECT * FROM tb_users where `users_email`='$email_l'");
                                        $fetch=mysqli_fetch_array($query_l);
                                        if(password_verify($password_l, $fetch['users_password'])){
            
                                            if($fetch['users_type']==1) {
                                            echo "<p class='text text-success'> login Successfully</p>";
                                            
                                            $_SESSION['user']=$fetch['users_fname']." ".$fetch['users_lname'];
                                            $_SESSION['id']=$fetch['id'];
                                            header('location:checkout-shipping.php');
                                            }
                                            
                                            else{
                                                echo "<p class='text text-danger'> Invalid email or password</p>";
                                            }
                
            
                                        }
                                        else{
                                            echo "<p class='text text-danger'> Invalid email or password</p>";
                                        }
            
            
                                    }
                                    
                                   

                                   
                                }?>

                                  <form action="checkout-review.php" method="POST">
                                     <div class="form-group required-field">
                                        <label>First Name  </label>
                                        <input type="text" class="form-control" name="fname" pattern="[A-Z a-z]{2,50}" required>
                                    </div>
                                    
                                    <div class="form-group required-field">
                                        <label>Last Name  </label>
                                        <input type="text" class="form-control" name="lname" pattern="[A-Z a-z]{2,50}" required>
                                    </div>

                               

                                    <div class="form-group required-field">
                                        <label>Street Address </label>
                                        <input type="text" class="form-control" name="address1" required>
                                        <input type="text" class="form-control" name="address2" required>
                                    </div><!-- End .form-group -->

                                    <div class="form-group required-field">
                                        <label>City  </label>
                                        <input type="text" class="form-control" pattern="[A-Z a-z]{2,50}" name="city" required>
                                    </div><!-- End .form-group -->

                                    <div class="form-group">
                                        <label>State/Province</label>
                                        <div class="select-custom">
                                            <select class="form-control" name="state">
                                                <option value="sindh">Sindh</option>
                                                <option value="punjab">Punjab</option>
                                                <option value="balochistan">Balochistan</option>
                                                <option value="kpk">KPK</option>
                                            </select>
                                        </div><!-- End .select-custom -->
                                    </div><!-- End .form-group -->

                                    <div class="form-group required-field">
                                        <label>Zip/Postal Code </label>
                                        <input type="text" pattern="[A-Z0-9]{2,10}" class="form-control" name="zip" required>
                                    </div><!-- End .form-group -->

                                    <div class="form-group">
                                        <label>Country</label>
                                        <div class="select-custom">
                                            <select class="form-control" name="country">
                                                <option value="pakistan">Pakistan</option>
                                                
                                            </select>
                                        </div><!-- End .select-custom -->
                                    </div><!-- End .form-group -->

                                    <div class="form-group required-field">
                                        <label>Phone Number </label>
                                        <div class="form-control-tooltip">
                                            <input type="tel" pattern="[0-9+]{11,13}|" class="form-control" name="phoneno" required>
                                            <span class="input-tooltip" data-toggle="tooltip" title="For delivery questions." data-placement="right"><i class="porto-icon-question-circle"></i></span>
                                        </div><!-- End .form-control-tooltip -->
                                    </div><!-- End .form-group --></li> <li>
                                <div class="checkout-step-shipping">
                                    <h2 class="step-title">Payment Methods</h2>

                                    <table class="table table-step-shipping">
                                        <tbody>
                                            <tr>
                                                <td><input type="radio" name="shipping-method" value="cc" required></td>
                                                
                                                <td>Credit Card</td>
                                                
                                            </tr>

                                            <tr>
                                                <td><input type="radio" name="shipping-method" value="cod" required></td>
                                                
                                                <td>Cash on Delivery</td>
                                                
                                            </tr>
                                            <tr>
                                                <td><input type="radio" name="shipping-method" value="bt" required></td>
                                                
                                                <td>Online Transfer</td>
                                                
                                            </tr>
                                        </tbody>
                                    </table>
                                </div><!-- End .checkout-step-shipping -->
                            </li>
                        </ul>
                    </div><!-- End .col-lg-8 -->
                               
                            

                           

                    <div class="col-lg-4">
                        <div class="order-summary">
                            <h3>Summary</h3>
                            

                            <h4>
                                <a data-toggle="collapse" href="#order-cart-section" class="collapsed" role="button" aria-expanded="false" aria-controls="order-cart-section">Your products in Cart</a>
                            </h4>
                           

                            <div class="collapse" id="order-cart-section">
                                <table class="table table-mini-cart">
                                    <tbody>
                                    <?php
                                  
                                  if($_SESSION['cart'] ?? null){
                                  foreach($_SESSION['cart'] as $cart)
                                   {
                                  ?>
                                        <tr>
                                            <td class="product-col">
                                                <figure class="product-image-container">
                                                    <a href="product.php?id=<?php echo $cart['id']?>" class="product-image">
                                                        <img style="height: 100px;width: 100px;" src="<?php echo $cart['image'];?>" alt="product">
                                                    </a>
                                                </figure>
                                                <div>
                                                    <h2 class="product-title">
                                                        <a href="product.php?id=<?php echo $cart['id']?>"><?php echo $cart['name'];?></a>
                                                    </h2>

                                                    <span class="product-qty">Qty: <?php echo $cart['quan']?></span>
                                                </div>
                                            </td>
                                            <td class="price-col">$<?php echo $cart['price'];?></td>
                                        </tr>

                                        <?php
                                            }
                                        }
                                        ?>
                                    </tbody>    
                                </table>
                            </div><!-- End #order-cart-section -->
                        </div><!-- End .order-summary -->
                    </div><!-- End .col-lg-4 -->
                </div><!-- End .row -->

                <div class="row">
                    <div class="col-lg-8">
                        <div class="checkout-steps-action">
                            <button type="submit" name="next" class="btn btn-primary float-right">NEXT</button>
                        </div><!-- End .checkout-steps-action -->
                    </div><!-- End .col-lg-8 -->
                </div><!-- End .row -->
            </div><!-- End .container -->
            </form>

            <div class="mb-6"></div><!-- margin -->
        </main><!-- End .main -->
<?php
include('include/footer.php');
?>