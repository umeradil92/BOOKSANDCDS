<?php
session_start();
ob_start();
// if(!isset($_SESSION['user']))
//      {
//       header('location:.php');
//      }
include('include/header.php');
include('DB_connection.php');
?>
    <div class="page-wrapper">
        <main class="main">
            <nav aria-label="breadcrumb" class="breadcrumb-nav">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Login</li>
                    </ol>
                </div><!-- End .container -->
            </nav>

            <div class="page-header">
                <div class="container">
                    <h1>Login and Create Account</h1>
                </div><!-- End .container -->
            </div><!-- End .page-header -->

            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="heading">
                            <h2 class="title">Login</h2>
                            <p>If you have an account with us, please log in.</p>
                        </div><!-- End .heading -->

                        <form action="" method="POST">
                            <input type="email" class="form-control" placeholder="Email Address" name="email_l" required>
                            <input type="password" class="form-control" placeholder="Password" name="password_l" min='3' max='16' required>

                            <div class="form-footer">
                                <button type="submit" name="login" class="btn btn-primary">LOGIN</button>
                            </div><!-- End .form-footer -->
                        </form>
                        <?php
                        if(isset($_POST['login'])){
                            $email_l=$_POST['email_l'];
                            $password_l=$_POST['password_l'];

                            $query_l=mysqli_query($con,"SELECT * FROM tb_users where `users_email`='$email_l'");
                            $fetch=mysqli_fetch_array($query_l);
                            if(password_verify($password_l, $fetch['users_password'])){

                                if($fetch['users_type']==1) {
                                echo "<p class='text text-success'> login Successfully</p>";
                                
                                $_SESSION['user']=$fetch['users_fname']." ".$fetch['users_lname'];
                                $_SESSION['id']=$fetch['id'];
                                header('location:index.php');
                                }
                                else if($fetch['users_type']==0) {
                                    echo "<p class='text text-success'> login Successfully</p>";
                                    
                                    $_SESSION['user']=$fetch['users_fname']." ".$fetch['users_lname'];
                                    $_SESSION['id']=$fetch['id'];
                                    header('location:admin/index.php');
                                    }
                                else{
                                    echo "<p class='text text-danger'> Invalid email or password</p>";
                                }
    

                            }
                            else{
                                echo "<p class='text text-danger'> Invalid email or password</p>";
                            }


                        }
                        
                        ?>
                    </div><!-- End .col-md-6 -->

                    <div class="col-md-6">
                        <div class="heading">
                            <h2 class="title">Create An Account</h2>
                            <p>By creating an account with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
                        </div><!-- End .heading -->

                        <form action="" method="POST">
                            <input type="text" class="form-control" placeholder="First Name" name="fname" required pattern="[A-Z a-z]{2,50}" title="Please Enter Alphabets">
                            <input type="text" class="form-control" placeholder="Last Name" name="lname" required pattern="[A-Z a-z]{2,50}" title="Please Enter Alphabets">

                            <h2 class="title mb-2">Login information</h2>
                            <input type="email" class="form-control" placeholder="Email Address" name="email" required>
                            <input type="password" class="form-control" placeholder="Password" name="password" min="3" max="16" required>
                            <input type="password" class="form-control" placeholder="Confirm Password" name="cpassword" min="3" max="16" required>
                            <div class="form-footer">
                                <button type="submit" name="submit" class="btn btn-primary">Create Account</button>
                            </div><!-- End .form-footer -->
                        </form>
                        <?php

                        
                        if(isset($_POST['submit'])){

                            $fname      =       $_POST['fname'];
                            $lname      =       $_POST['lname'];
                            $email      =       $_POST['email'];
                            $password   =       $_POST['password'];
                            $cpassword  =       $_POST['cpassword'];
                            $usertype   =       1;

                            if($password==$cpassword){

                                $encrypt_password = password_hash($password, PASSWORD_DEFAULT);

                                $query=mysqli_query($con,"INSERT INTO tb_users(`users_fname`,`users_lname`,`users_email`,`users_password`,`users_type`) VALUES ('$fname','$lname','$email','$encrypt_password','$usertype')");

                                if($query){
                                    echo "<p class='text text-success'> Registered Successfully</p>";
                                }

                            }


                        }
                        
                        ?>
                    </div><!-- End .col-md-6 -->
                </div><!-- End .row -->
            </div><!-- End .container -->

            <div class="mb-5"></div><!-- margin -->
        </main><!-- End .main -->
<?php
include('include/footer.php');
?>