<?php
session_start();
ob_start();
include('include/header.php');

if(isset($_POST['cart'])){
    $items = array(
        'id'       => $_POST['id'],
        'name'     => $_POST['pname'],
        'price'    => $_POST['price'],
        'image'    => $_POST['image'],
        'quan'     => 1,
    );
    if(empty($_SESSION['cart'])){
    $_SESSION['cart'][0] = $items;
    }
    else
    {
        $id_c = array_column($_SESSION['cart'],'id');
        if(in_array($items['id'],$id_c)){
            echo "<p class='text text-danger'>Product already exist</p>";
        }
        else
        {
            $count = count($_SESSION['cart']);
            $_SESSION['cart'][$count] = $items;
        }    
    }
}

$quan = 1;

if(isset($_POST['action']) && $_POST['action']=="change"){
    foreach($_SESSION["cart"] as $cart){
        if($cart['id'] === $_POST["id"]){
            $quan = $_POST["quantity"];
            //echo "<h1>";
            // echo $value['quantity'];
            //echo "</h1>";
            break; // Stop the loop after we've found the product
        }
    }
}                
?>
    <div class="page-wrapper">
        <main class="main">
            <nav aria-label="breadcrumb" class="breadcrumb-nav mb-4">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Shopping Cart</li>
                    </ol>
                </div><!-- End .container -->
            </nav>

            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="cart-table-container">
                            <table class="table table-cart">
                                <thead>
                                    <tr>
                                        <th class="product-col">Product</th>
                                        <th class="price-col">Price</th>
                                        <th class="qty-col">Qty</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        if($_SESSION['cart'] ?? null){
                                            foreach($_SESSION['cart'] as $key => $cart){
                                    ?>
                                            <tr class="product-row">
                                                <td class="product-col">
                                                    <figure class="product-image-container">
                                                        <a href="product.php?id=<?php echo $cart['id']?>">
                                                            <img src="<?php echo $cart['image']?>" alt="product" style="height: 352px;width: 214px">
                                                        </a>
                                                    </figure>
                                                    <h2 class="product-title">
                                                        <a href="product.php?id=<?php echo $cart['id']?>"><?php echo $cart['name']?></a>
                                                    </h2>
                                                </td>
                                                <td data-price="<?php echo $cart['price'];?>" class='price'>$<?php echo $cart['price'];?></td>
                                                <td>
                                                    <form action="" method="POST">
                                                        <input type='hidden' name='id' value="<?php echo $cart['id']; ?>" />
                                                        <input type='hidden' name='action' value="change" />
                                                        <input class="vertical-quantity form-control" type="text" value="<?php echo $quan?>"  name='quantity'  onchange="this.form.submit()">
                                                    </form>
                                                </td>
                                                <td>$<?php echo $cart['price']*$quan?></td>
                                            </tr>             
                                            <tr class="product-action-row">
                                                <td colspan="4" class="clearfix">
                                                    <div class="float-left">
                                                    </div><!-- End .float-left -->                                            
                                                    <div class="float-right">
                                                        <!-- <a href="#" title="Edit product" class="btn-edit"><span class="sr-only">Edit</span><i class="porto-icon-pencil"></i></a> -->
                                                        <a href="cart.php?id=<?php echo $cart['id']?>" title="Remove product" class="btn-remove"><span class="sr-only">Remove</span></a>
                                                    </div><!-- End .float-right -->
                                                </td>
                                            </tr>
                                   
                                    <?php
                                            }
                                        }
                                    ?>
                                </tbody>

                                <tfoot>
                                    <tr>
                                        <td colspan="4" class="clearfix">
                                            <div class="float-left">
                                                <a href="index.php" class="btn btn-outline-secondary">Continue Shopping</a>
                                            </div><!-- End .float-left -->
                                            <div class="float-right">
                                                <form action="" method="post">
                                                    <button  type="submit" name="destroy" class="btn btn-outline-secondary btn-clear-cart">Clear Shopping Cart</button>
                                                </form>
                                                <?php 
                                                if(isset($_POST['destroy'])){
                                                    unset($_SESSION["cart"]);

                                                }                                                
                                                ?> 
                                            </div>
                                            <!--<div class="float-right"><form action="" method="post">
                                            <button type="submit" name="update_cart" style="margin-right: 5px;" class="btn btn-outline-secondary btn-update-cart">Update Shopping Cart</button>
                                            </form>
                                            ?>
                                            </div>--><!-- End .float-right -->
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div><!-- End .cart-table-container -->

                        
                    </div><!-- End .col-lg-8 -->

                    <div class="col-lg-4">
                        <div class="cart-summary">
                            <h3>Summary</h3>
                           <!-- <h4>
                                <a data-toggle="collapse" href="#total-estimate-section" class="collapsed" role="button" aria-expanded="false" aria-controls="total-estimate-section">Estimate Shipping and Tax</a>
                            </h4> -->
                            <!--<div class="collapse" id="total-estimate-section">
                                <form action="#">
                                    <div class="form-group form-group-sm">
                                        <label>Country</label>
                                        <div class="select-custom">
                                            <select class="form-control form-control-sm">
                                                <option value="USA">United States</option>
                                                <option value="Turkey">Turkey</option>
                                                <option value="China">China</option>
                                                <option value="Germany">Germany</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group form-group-sm">
                                        <label>State/Province</label>
                                        <div class="select-custom">
                                            <select class="form-control form-control-sm">
                                                <option value="CA">California</option>
                                                <option value="TX">Texas</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group form-group-sm">
                                        <label>Zip/Postal Code</label>
                                        <input type="text" class="form-control form-control-sm">
                                    </div>
                                    <div class="form-group form-group-custom-control">
                                        <label>Flat Way</label>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="flat-rate">
                                            <label class="custom-control-label" for="flat-rate">Fixed $5.00</label>
                                        </div>
                                    </div>
                                    <div class="form-group form-group-custom-control">
                                        <label>Best Rate</label>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="best-rate">
                                            <label class="custom-control-label" for="best-rate">Table Rate $15.00</label>
                                        </div>
                                    </div>
                                </form>
                            </div>-->

                            <table class="table table-totals">
                                <tbody>
                                    <?php
                                    if(isset($_SESSION["cart"])){
                                        $total_price = 0;
                                        foreach ($_SESSION["cart"] as $product){          
                                            $total_price += ($product["price"]*$quan);
                                        }
                                    }
                                    else{
                                        $total_price = 0;
                                    }
                                    ?>
                                    <tr>
                                        <td>Subtotal</td>
                                        <td><?php echo '$'.$total_price ?></td>   
                                    </tr>
                                    <tr>
                                        <td>Tax</td>
                                        <td>$0</td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td>Order Total</td>
                                        <td><?php echo '$'.$total_price ?></td>
                                    </tr>
                                </tfoot>
                            </table>

                            <div class="checkout-methods">
                                <a type="submit" href="checkout-shipping.php" class="btn btn-block btn-sm btn-primary">Go to Checkout</a>
                            </div><!-- End .checkout-methods -->
                        </div><!-- End .cart-summary -->
                    </div><!-- End .col-lg-4 -->
                </div><!-- End .row -->
            </div><!-- End .container -->

            <div class="mb-6"></div><!-- margin -->
        </main><!-- End .main -->
        <?php
        if(isset($_GET['id'])){
            foreach($_SESSION['cart'] as $key=>$value){
                if($_GET['id'] == $value['id']){
                    unset($_SESSION['cart'][$key]);
                    header('location:cart.php');
                }
            }
        }
        ?>

<?php
    include('include/footer.php');
?>