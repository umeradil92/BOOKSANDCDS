<?php
session_start();

ob_start();
include('include/header.php');

?>
<div class="container" style="align-items: center;text-align: center;">
<div class="row mx-auto">
	<div class="col-md-6 mx-auto mt-5 mb-5" style="border: 1px solid black">
  <table class="table" id="myTable">
    <thead class="black white-text">
      <tr>
        <th scope="col">Order Number</th>
        <th scope="col">City</th>
        <th scope="col">Payment Method</th>
        <th scope="col">Total</th>
      </tr>
    </thead>
    <tbody>
          
  <?php 
  
   $con=mysqli_connect("localhost","root","","bookstore_db");
   $id=$_SESSION['id'];
   $query=mysqli_query($con,"SELECT * FROM tb_checkout where checkout_fk_user= ".$_SESSION['id']);

   

   while($fetch= mysqli_fetch_array($query)){
   
   ?>
      <tr>
        <td><?php echo $fetch['checkout_orderno'] ?></td>
        <td><?php echo $fetch['checkout_add_city'] ?></td>
        <td><?php echo $fetch['checkout_paymentmethod'] ?></td>
        <td><?php echo $fetch['checkout_price'] ?></td>
       
      </tr>
      <?php 
   }
  ?>
    </tbody>
  </table>
</div>
</div>
<?php
include('include/footer.php');
ob_end_flush();
?>