<?php


$hostname="localhost";
$username="root";
$password=null;
$database="bookstore_db";


$con=mysqli_connect($hostname,$username,$password,$database);


?>