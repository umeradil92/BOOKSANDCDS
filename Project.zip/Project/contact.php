<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .smoke{
            border-bottom:15px solid #ffc300;
            border-radius:0px 0px 80px 0px;
            width:500px;
            height:auto;
            margin-left:390px;
        }

        .smoke ul{
            margin:0;
            padding:0;
            display:flex;
            }
            
        .smoke ul li{
            list-style-type:none;
            color:black;
            font-size:50px;
            font-weight:bold;
            letter-spacing:20px;
            filter:blur(1px);
            }
            
        .smoke ul:hover li{
            animation:animate;
            animation-duration:4s;
            animation-timing-function:linear;
            animation-iteration-count:forwards;
            }
            
        @keyframes animate{
            0%{
                transform:rotate(0deg) translatey(0px);
                opacity:1;
                filter:blur(1px);
                }
        100%{
                transform:rotate(20deg) translatey(-200px);
                opacity:0;
                filter:blur(20px);
                }
            }
            
        .smoke ul li:nth-child(1){
            animation-delay:0s;
            }
            
        .smoke ul li:nth-child(2){
            animation-delay:0.4s;
            }
            
        .smoke ul li:nth-child(3){
            animation-delay:0.6s;
            }
            
        .smoke ul li:nth-child(4){
            animation-delay:0.8s;
            }
            
        .smoke ul li:nth-child(5){
            animation-delay:1.2s;
            }
            
        .smoke ul li:nth-child(6){
            animation-delay:1.6s;
            }
        .smoke ul li:nth-child(7){
            animation-delay:2.0s;
            }
        .smoke ul li:nth-child(8){
            animation-delay:2.4s;
            }
        .smoke ul li:nth-child(9){
            animation-delay:2.8s;
            }
    </style>
</head>
<body>

    
<?php
include('include/header.php');
?>
    <div class="page-wrapper">
        <main class="main">
            <nav aria-label="breadcrumb" class="breadcrumb-nav">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                    </ol>
                </div><!-- End .container -->
                
            </nav><div class="page-header">
                <div class="smoke">
                    <ul>
                        <li>C</li>
                        <li>O</li>
                        <li>N</li>
                        <li>T</li>
                        <li>A</li>
                        <li>C</li>
                        <li>T</li>
                        <li>U</li>
                        <li>S</li>
                        <span style="font-size:50px;letter-spacing:8px;filter:blur(1px);font-weight:bold;line-height:72px;color:black;">
                        </span>
                    </ul>
                </div><!-- End .container -->
            </div><!-- End .page-header -->

            <div class="container">               
                <div class="row">
                    <div class="col-md-8">
                        <h2 class="light-title">Write <strong>Us</strong></h2>

                        <form action="#">
                            <div class="form-group required-field">
                                <label for="contact-name">Name</label>
                                <input type="text" class="form-control" id="contact-name" name="contact-name" required>
                            </div><!-- End .form-group -->

                            <div class="form-group required-field">
                                <label for="contact-email">Email</label>
                                <input type="email" class="form-control" id="contact-email" name="contact-email" required>
                            </div><!-- End .form-group -->

                            <div class="form-group">
                                <label for="contact-phone">Phone Number</label>
                                <input type="tel" class="form-control" id="contact-phone" name="contact-phone">
                            </div><!-- End .form-group -->

                            <div class="form-group required-field">
                                <label for="contact-message">What’s on your mind?</label>
                                <textarea cols="30" rows="1" id="contact-message" class="form-control" name="contact-message" required></textarea>
                            </div><!-- End .form-group -->

                            <div class="form-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div><!-- End .form-footer -->
                        </form>
                    </div><!-- End .col-md-8 -->

                    <div class="col-md-4">
                        <h2 class="light-title">Contact <strong>Details</strong></h2>

                        <div class="contact-info">
                            <div>
                                <i class="porto-icon-phone"></i>
                                <p><a href="tel:">0201 203 2032</a></p>
                                <p><a href="tel:">0201 203 2032</a></p>
                            </div>
                            <div>
                                <i class="porto-icon-mobile"></i>
                                <p><a href="tel:">201-123-3922</a></p>
                                <p><a href="tel:">302-123-3928</a></p>
                            </div>
                            <div>
                                <i class="porto-icon-mail-alt"></i>
                                <p><a href="mailto:#">porto@gmail.com</a></p>
                                <p><a href="mailto:#">porto@portotemplate.com</a></p>
                            </div>
                            <div>
                                <i class="porto-icon-skype"></i>
                                <p>porto_skype</p>
                                <p>porto_template</p>
                            </div>
                        </div><!-- End .contact-info -->
                    </div><!-- End .col-md-4 -->
                </div><!-- End .row -->
            </div><!-- End .container -->

            <div class="mb-8"></div><!-- margin -->
        </main><!-- End .main -->
<?php
include('include/footer.php');
?>''
</body>
</html>