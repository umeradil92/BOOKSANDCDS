
<?php
include('include/header.php');
include('DB_connection.php');

$id = $_GET['id'];
$query = mysqli_query($con,"SELECT * FROM tb_products WHERE `id`='$id'");
$fetch = mysqli_fetch_array($query);
$fk_id = $fetch['products_fk_category'];
$cat = mysqli_query($con,"SELECT category_name FROM tb_categories WHERE `id`='$fk_id'");
$fetch_cat = mysqli_fetch_array($cat);


$path = "admin/uploads/";
?>
    <div class="page-wrapper">
        <main class="product-detail-page main">
            <nav aria-label="breadcrumb" class="breadcrumb-nav">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php" style="font-family:cursive">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo $fetch_cat['category_name']?>.php"><?php echo $fetch_cat['category_name']?></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo $fetch['products_name']?></li>
                    </ol>
                </div><!-- End .container -->
            </nav>


            <form action="cart.php" method="post">
            <div class="bg-white" style="padding: 4rem 0 5rem;">
                <div class="container" id="product_panel">
                    <div class="row">
                        <div class="col-lg-9">
                            <div class="row row-sm">
                                <div class="col-11-4">
                                    <img src="<?php echo $path.$fetch['products_image']?>" style="width: 100%; height: auto;">
                                </div>
                                <div class="col-11-5">
                                    <div class="product-details-list">
                                        <h2 class="product-title"><?php echo $fetch['products_name']?></h2>
                                        <div class="ratings-container mb-1">
                                          
                                        </div><!-- End .product-container -->
                                        <div class="price-box">
                                            <span class="product-price"><?php echo $fetch['products_price']?>$</span>
                                        </div><!-- End .price-box -->
                                       <!-- <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolre eu fugiat nulla pariatur excepteur sint occaecat cupidatat non. Duis aute irure dolor in reprehenderit in voluptate velit esse.</p>-->
                                        <div class="product-property">
                                            <h3 class="property-name">Product Code: </h3>
                                            <h4 class="property-value"><?php echo $fetch['products_id']?></h4>
                                        </div>
                                        <div class="product-property">
                                            <h3 class="property-name">Manufacturer: </h3>
                                            <h4 class="property-value"><?php echo $fetch['products_manufacturer']?></h4>
                                        </div>
                                        <div class="product-property">
                                            <h3 class="property-name">Stock: </h3>
                                            <h4 class="property-value"><?php echo $fetch['products_stock']?></h4>
                                        </div>

                                        <?php if ($fetch['products_type']==0){

                                        }
                                        
                                        elseif($fetch['products_type']==1){

                                          echo "<div class='product-property'>
                                            <h3 class='property-name'>Type: </h3>
                                            <h4 class='property-value'>Readable</h4>
                                        </div>";
                                        }

                                        else{

                                            echo "<div class='product-property'>
                                            <h3 class='property-name'>Type: </h3>
                                            <h4 class='property-value'>Re-Writable</h4>
                                        </div>";
                                        }

                                        ?>
                                        <input type="hidden" name="id" value='<?php  echo $id?>'>
                                        <input type="hidden" name="pname" value='<?php echo $fetch['products_name']?>'>
                                        <input type="hidden" name="price" value='<?php echo $fetch['products_price']?>'>
                                        <input type="hidden" name="image" value='<?php echo $path.$fetch['products_image']?>'>
                                       
                                        
                                        
                                        
                                        <button class="btn" type="submit" name="cart" style="margin-top: 200px;"><i class="minicart-icon"></i>ADD TO BAG</button>
                                    </div><!-- End .product-details -->
                                </div>
                                </form>
                                <div class="col-lg-12 home-product-tabs mt-2">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="description-tab" data-toggle="tab" href="#description" role="tab" aria-controls="description" aria-selected="true">DESCRIPTION</a>
                                        </li> 
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
                                          <p><?php echo $fetch['products_description']?></p>
                                        </div><!-- End .tab-pane -->
                                        <div class="tab-pane fade" id="size-guide" role="tabpanel" aria-labelledby="size-guide-tab">
                                            <div class="row">
                                                <div class="col-sm-4 text-center">
                                                    <img src="images/products/detail/body-shape.png">
                                                </div>
                                                <div class="col-sm-8">

                                                </div>
                                            </div>
                                        </div><!-- End .tab-pane -->
                                        <div class="tab-pane fade" id="additional-information" role="tabpanel" aria-labelledby="additional-information-tab">

                                        </div><!-- End .tab-pane -->
                                        <div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab">
                                            <div class="reviewpanel">
                                                <h2>1 review for the Night Before</h2>
                                                <div class="review">
                                                    <h3>Maria - <span>June 7, 2013</span></h3>
                                                    <p>He really is the cutest little man. Swoooon!</p>
                                                </div>
                                            </div>
                                            <div class="submit-review-panel">
                                                <h2>Add a review</h2>
                                                <form action="#" method="get">
                                                    <div class="form-group">
                                                        <label for="review">Your review * </label>
                                                        <textarea class="form-control" rows="5" id="review"></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="name">Name * </label>
                                                        <input type="text" name="name" class="form-control">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="email">Email * </label>
                                                        <input type="email" name="email" class="form-control">
                                                    </div>
                                                    <button type="submit" class="btn">Submit</button>
                                                </form>
                                            </div>
                                        </div><!-- End .tab-pane -->
                                    </div><!-- End .tab-content -->
                                </div><!-- End .home-product-tabs -->
                            </div>
                        </div>
                        <div class="sidebar-overlay"></div>
                        <div class="sidebar-toggle"><i class="porto-icon-right-open"></i></div>
                      
                    </div>
                    
                </div>
            </div>
        </main>
<?php
include('include/footer.php');
?>