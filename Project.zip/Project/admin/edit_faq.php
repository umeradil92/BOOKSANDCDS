      <?php
include('header.php');

      ?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">
<?php
include('sidebar.php');
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

      <?php
include('topbar.php');
      ?>

    <?php
      $id = $_GET['id'];
      $query=mysqli_query($con,"SELECT * FROM tb_faq WHERE `id` = '$id'");
      $fetch= mysqli_fetch_array($query);
   
   ?>
        <!-- Begin Page Content -->
        <div class="container">
          <div class="row">
            <div class="col-md-12">
      <form class="form-horizontal" action="" method="post">
    
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Enter Question:</label>
      <div class="col-sm-4">          
        <textarea name="ques_insert" style="height: 100px;width: 300px;" required="" ><?php echo $fetch['faq_ques']?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Enter Answer:</label>
      <div class="col-sm-4">          
        <textarea name="ans_insert" style="height: 100px;width: 300px;" required=""><?php echo $fetch['faq_ans']?></textarea>
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-4">          
        <input type="submit" name="submit" value="Update" class="btn btn-primary" style="border-radius: 20px;width: 150px;">
        <a href="../admin/faq_tbl.php"><input type="button" name="Faq_back" value="Go Back" class="btn btn-danger" style="border-radius: 20px;width: 150px;"></a>
      </div>
      
    </div>
  </form>
  <?php
       if(isset($_POST['submit'])){
       $ques = $_POST['ques_insert'];
       $ans  = $_POST['ans_insert'];
       $query2 = mysqli_query($con,"UPDATE `tb_faq` SET `faq_ques`='$ques',`faq_ans`='$ans' WHERE `id`='$id'");
       if($query2){
        echo "<p class='text text-success'> Updated Successfully</p>";
        header('location:../admin/faq_tbl.php');
       }
       }
  
  ?>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <?php
include('footer.php');
      ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>
