      <?php
     
include('header.php');
      ?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">
<?php
include('sidebar.php');
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

      <?php
include('topbar.php');
      ?>

        <!-- Begin Page Content -->
        <div class="container">
          <div class="row">
            <div class="col-md-12">
    <form class="form-horizontal" action="" method="post">
    
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Category Name:</label>
      <div class="col-sm-4">          
        <input type="text" class="form-control" id="name" placeholder="Enter Category Name" name="cname" required pattern="[A-Z a-z]{2,50}" title="Please Enter Alphabets">
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-4">          
        <input type="submit" name="submit" value="Insert" class="btn btn-primary" style="border-radius: 20px;width: 150px;">
        <a href="../admin/categories_tbl.php"><input type="button" name="cat_back" value="Go Back" class="btn btn-danger" style="border-radius: 20px;width: 150px;"></a>
      </div>
    </div>
  </form>

  <?php
       if(isset($_POST['submit'])){
       $cname =     $_POST['cname'];
       $number =    rand(0, 9);
       $letters =   range('A','Z');
       $ccode=      $letters[rand(0,25)].$number;
       $query = mysqli_query($con,"INSERT INTO tb_categories(`category_id`,`category_name`) VALUES ('$ccode','$cname')");
       if($query){
        echo "<p class='text text-success'> Added Successfully</p>";
        header('location:../admin/categories_tbl.php');
       }
       }
  
  ?>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <?php
include('footer.php');
      ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>
