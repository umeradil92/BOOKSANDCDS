<?php
include('header.php');

      ?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">
<?php
include('sidebar.php');
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

      <?php
include('topbar.php');
      ?>
      <?php
      $id = $_GET['id'];
      $query= mysqli_query($con,"SELECT * FROM tb_products WHERE `id` = '$id'");
      $fetch= mysqli_fetch_array($query);
   
   ?>

        <!-- Begin Page Content -->
        <div class="container">
          <div class="row">
            <div class="col-md-12">
    <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
    
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Product Name:</label>
      <div class="col-sm-4">          
        <input type="text" class="form-control" id="pwd" placeholder="Enter Name" name="pname" required="" pattern="[A-Z a-z]{2,50}" title="Please Enter Alphabets" value="<?php echo $fetch['products_name']?>">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Product Category:</label>
      <select class="form-control col-sm-3" name = "pcategory" style="margin-left: 12px;">
        <?php 
           $cat_fk = $fetch['products_fk_category'];
           $select = mysqli_query($con,"SELECT * FROM tb_categories WHERE `id`='$cat_fk'");
           $cat = mysqli_fetch_array($select);
        ?>
        <option value = "<?php echo $cat['id']?>" selected><?php echo $cat['category_name']?></option>

        <?php 
           $select_2 = mysqli_query($con,"SELECT * FROM tb_categories WHERE `id`!='$cat_fk'");
           $cat_2 = mysqli_fetch_array($select_2);
        ?>
        <option value = "<?php echo $cat_2['id']?>"><?php echo $cat_2['category_name']?></option>
         </select>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Product Image:</label>
      <div class="col-sm-4">
          <img src="uploads/<?php echo $fetch['products_image']?>" height="100" width="100" /><br />  <br /> 
          <label style="margin-left: -12px;" class="control-label col-sm-8" for="pwd">OR Choose a new file</label>       
        <input type="file" name="pimage"  accept="image/png, image/jpeg, image/jpg" >
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="pwd">Product Manufacturer:</label>
      <div class="col-sm-4">          
        <input type="text" class="form-control" id="pwd" placeholder="Enter Manufacturer Name" name="pmanufacturer" required="" pattern="[A-Z a-z]{2,50}" title="Please Enter Alphabets" value="<?php echo $fetch['products_manufacturer']?>">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Product Price:</label>
      <div class="col-sm-2">          
        <input type="number" class="form-control" id="pwd" placeholder="Enter Price" name="pprice" pattern="[0-9]{1,100}" required="" value="<?php echo $fetch['products_price']?>">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Product Type:</label>
      <select class="form-control col-sm-3" name = "ptype" style="margin-left: 12px;">
      <?php if($fetch['products_type']==0){?>
            <option value = "0" <?php echo "selected"?>>-----</option>
            <option value = "1">Readable</option>
            <option value = "2">Re writable</option>
            <?php } 
      elseif($fetch['products_type']==1) {
          ?>
            <option value = "0" >-----</option>
            <option value = "1" <?php echo "selected"?>>Readable</option>
            <option value = "2">Re writable</option>
          <?php }
          else {
          ?>
             <option value = "0" >-----</option>
             <option value = "1" >Readable</option>
             <option value = "2" <?php echo "selected"?>>Re writable</option>
          <?php } ?>
         </select>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Product Status:</label>
      <select class="form-control col-sm-3" name = "pstatus" style="margin-left: 12px;">
      <?php if($fetch['products_status']==1){?>
            <option value = "1" <?php echo "selected"?>>Active</option>
            <option value = "0">Inactive</option>
            <?php } 
      else {
          ?>
            <option value = "0" <?php echo "selected"?>>Inactive</option>
            <option value = "1" >Active</option>
            <?php } 
          ?>
         </select>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Product Description:</label>
      <div class="col-sm-4">          
        <textarea name="pdescription" style="height: 150px;width: 300px;" required=""><?php echo $fetch['products_description']?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Product Stock:</label>
      <div class="col-sm-2">          
        <input type="number" class="form-control" id="pwd" placeholder="Enter Stock" name="pstock" required="" value="<?php echo $fetch['products_stock']?>">
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-4">          
        <input type="submit" name="submit" value="Update" class="btn btn-primary" style="border-radius: 20px;width: 150px;">
        <a href="../admin/products_tbl.php"><input type="button" name="cat_back" value="Go Back" class="btn btn-danger" style="border-radius: 20px;width: 150px;"></a>
      </div>
    </div>
  </form>

  <?php
       if(isset($_POST['submit'])){
       $pname = $_POST['pname'];
       $pcategory  = $_POST['pcategory'];
       $pmanufacturer  = $_POST['pmanufacturer'];
       $pprice  = $_POST['pprice'];
       $ptype  = $_POST['ptype'];
       $pstatus  = $_POST['pstatus'];
       $pdescription  = $_POST['pdescription'];
       $pstock     =     $_POST['pstock'];
       $image_name = $_FILES['pimage']['name'];
       $image_tmp_dir = $_FILES['pimage']['tmp_name'];
       $target_dir = 'uploads/';
      // echo "<br> name ".$pname."<br> image-name ".$image_name."<br> manufacturer ".$pmanufacturer."<br> Price ".$pprice."<br> Type ".$ptype."<br> Status ".$pstatus."<br> Description ".$pdescription."<br> Stock ".$pstock."<br> Category ".$pcategory;
       
       if($image_name == null){
        $query2 = mysqli_query($con,"UPDATE `tb_products` SET `products_name`='$pname',`products_manufacturer`='$pmanufacturer',`products_price`='$pprice',`products_type`='$ptype',`products_status`='$pstatus',`products_description`='$pdescription',`products_stock`='$pstock',`products_fk_category`='$pcategory' WHERE `id`='$id'");
        if($query2){
        echo "<p class='text text-success'> Added Successfully</p>";
        header('location:../admin/products_tbl.php');
          }
       }
       else{
        $query3 = mysqli_query($con,"UPDATE `tb_products` SET `products_name`='$pname',`products_image`='$image_name',`products_manufacturer`='$pmanufacturer',`products_price`='$pprice',`products_type`='$ptype',`products_status`='$pstatus',`products_description`='$pdescription',`products_stock`='$pstock',`products_fk_category`='$pcategory' WHERE `id`='$id'");
        if($query3){
         move_uploaded_file($image_tmp_dir,$target_dir.$image_name);
         echo "<p class='text text-success'> Added Successfully</p>";
         header('location:../admin/products_tbl.php');
        }
       
       }


       
       }
  
  ?>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <?php
include('footer.php');
      ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>
