<?php
include('header.php');

      ?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">
<?php
include('sidebar.php');
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

      <?php
include('topbar.php');
      ?>

<?php
      $id = $_GET['id'];
      $query=mysqli_query($con,"SELECT * FROM tb_users WHERE `id` = '$id'");
      $fetch= mysqli_fetch_array($query);
   
   ?>

        <!-- Begin Page Content -->
        <div class="container">
          <div class="row">
            <div class="col-md-12">
            <form class="form-horizontal" action="" method="post">
    
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">First Name:</label>
      <div class="col-sm-4">          
        <input type="text" class="form-control"  placeholder="Enter First Name" name="fname" required="" pattern="[A-Z a-z]{2,50}" title="Please Enter Alphabets" value="<?php echo $fetch['users_fname']?>">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Last Name:</label>
      <div class="col-sm-4">          
        <input type="text" class="form-control"  placeholder="Enter Last Name" name="lname" required="" pattern="[A-Z a-z]{2,50}" title="Please Enter Alphabets" value="<?php echo $fetch['users_lname']?>">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Email:</label>
      <div class="col-sm-4">          
        <input type="email" class="form-control"  placeholder="Enter Email" name="email" required="" value="<?php echo $fetch['users_email']?>">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Password:</label>
      <div class="col-sm-4">          
        <input type="password" class="form-control" placeholder="Enter Password" name="password" min="3" max="16">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Confirm Password:</label>
      <div class="col-sm-4">          
        <input type="password" class="form-control" placeholder="Confirm Password" name="cpassword" min="3" max="16">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">User Type:</label>
      <div class="col-sm-4">          
      <select class="form-control" name = "usertype">
      <?php if($fetch['users_type']==1){?>
            <option value = "1"<?php echo "selected"?> >User</option>
            <option value = "0" >Admin</option>
      <?php } 
      else {
          ?>
            <option value = "0" <?php echo "selected"?>>Admin</option>
            <option value = "1" >User</option>

    <?php } 
          ?>
         </select>
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-4">          
        <input type="submit" name="submit" value="update" class="btn btn-primary" style="border-radius: 20px;width: 150px;">
        <a href="../admin/user_tbl.php"><input type="button" name="user_back" value="Go Back" class="btn btn-danger" style="border-radius: 20px;width: 150px;"></a>
      </div>
    </div>
  </form>

  <?php
       if(isset($_POST['submit'])){
       $fname = $_POST['fname'];
       $lname  = $_POST['lname'];
       $email  = $_POST['email'];
       $password  = $_POST['password'];
       $cpassword  =  $_POST['cpassword'];
       $usertype  = $_POST['usertype'];

       if($password==null && $cpassword=null){
        $query2=mysqli_query($con,"UPDATE `tb_users` SET `users_fname`='$fname',`users_lname`='$lname',`users_email`='$email',`users_type`='$usertype' WHERE `id`='$id'");
        if($query2){
            echo "<p class='text text-success'> Updated Successfully</p>";
            header('location:../admin/user_tbl.php');
          }
    }
       else{
       if($password==$cpassword){
       $encrypt_password = password_hash($password, PASSWORD_DEFAULT);
       $query3=mysqli_query($con,"UPDATE `tb_users` SET `users_fname`='$fname',`users_lname`='$lname',`users_email`='$email',`users_password`='$encrypt_password',`users_type`='$usertype' WHERE `id`='$id'");
       if($query3){
          echo "<p class='text text-success'> Updated Successfully</p>";
          header('location:../admin/user_tbl.php');
        }
    }
       else{
        echo "<p class='text text-danger'> Please confirm the password</p>";
       }
       

       }
       }
  
  ?>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <?php
include('footer.php');
      ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>
