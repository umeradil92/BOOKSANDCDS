<?php
include('header.php');

?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">
<?php
include('sidebar.php');
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

      <?php
include('topbar.php');
      ?>
<!-- container-->
<div class="container">
    <br>
 
   <a href="insert_categories.php"><input type="submit" name="insert" value="Add New" class="btn btn-primary" style="border-radius: 20px;width: 150px; margin-bottom: 20px;"></a>
<table class="table" id="myTable">
    <thead class="black white-text">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Category Code</th>
        <th scope="col">Category Name</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
    <?php 
   
   $query=mysqli_query($con,"SELECT * FROM tb_categories");

   

   while($fetch= mysqli_fetch_array($query)){
   
   ?>
      <tr>
        <th scope="row"><?php echo $fetch['id'] ?></th>
        <td><?php echo $fetch['category_id'] ?></td>
        <td><?php echo $fetch['category_name'] ?></td>
        <td><a class="btn btn-raised btn-primary btn-sm" href="edit_categories.php?id=<?php echo $fetch['id'] ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>


            ||


            <button style="border: none;padding: 0;background: none;" data-toggle="modal" class="delete" data-target="#exampleModal" data-href="categories_tbl.php?id=<?php echo $fetch['id']?>">
            <a class="btn btn-raised btn-danger btn-sm" href="#"><i class="fa fa-trash" aria-hidden="true"></i></a>
            </button>
        </td>
      </tr>
      <?php 
   }
  ?>
    </tbody>
  </table>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       <a id="confirm_delete" href=""> <button type="button" class="btn btn-primary">Yes</button></a>
       <?php
        if(isset($_GET['id'])){
          $id = $_GET['id'];
          $delete = mysqli_query($con,"DELETE FROM tb_categories WHERE `id`='$id'");
          if($delete)
          {
            header('location:../admin/categories_tbl.php');
          }
        }
        ?>
        
      </div>
    </div>
  </div>
</div>

<script>
  $(document).ready(function(){
    $(".delete").click(function(){
      var url = $(this).data("href");
      //console.log(url);
      $("#confirm_delete").attr("href", url);
    });
  });

  $(document).ready( function () {
    $('#myTable').DataTable();
} );
    </script>

  
</div>
      <!-- End of Main Content -->
</div>
      <!-- Footer -->
      <?php
include('footer.php');
      ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>
