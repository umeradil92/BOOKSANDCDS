<?php   
  include('header.php');
?>

<body id="page-top">
  <!-- Page Wrapper -->
  <div id="wrapper">
  <?php
    include('sidebar.php');
  ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

      <?php
        include('topbar.php');
      ?>

        <!-- Begin Page Content -->
       <div class="container" style="height:100%; width:100%">
        <div class="row">
          <div class="col-md-6 mb-4">
            <a href="user_tbl.php" style="text-decoration: none;"><img src="img/user-tbl.png" style="height: 300px; width: 300px;">
            <h4 style="margin-left: 120px; margin-top: 30px;">Users</h4></a>
          </div>
          <div class="col-md-6 mb-4">
            <a href="products_tbl.php" style="text-decoration: none;"><img src="img/product-tbl.png" style="height: 300px; width: 300px;">
            <h4 style="margin-left: 120px; margin-top: 30px;">Products</h4></a>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 mt-4">
            <a href="categories_tbl.php" style="text-decoration: none;"><img src="img/stock-tbl.jpg" style="height: 300px; width: 300px;">
            <h4 style="margin-left: 120px; margin-top: 30px;">Categories</h4></a>
          </div>
          <div class="col-md-6 mt-4">
            <a href="faq_tbl.php" style="text-decoration: none;"><img src="img/faq-tbl.png" style="height: 300px; width: 300px;">
            <h4 style="margin-left: 120px; margin-top: 30px;">Faqs</h4></a>
          </div>
        </div>
       </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <?php
include('footer.php');
      ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>
