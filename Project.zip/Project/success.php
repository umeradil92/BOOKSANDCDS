<?php
ob_start();
include('include/header.php');
include('DB_connection.php');
session_start();


?>
    <div class="page-wrapper">
        <main class="main">
            <nav aria-label="breadcrumb" class="breadcrumb-nav mb-2">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php" style="font-family:cursive">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page" style="font-family:cursive">Checkout</li>
                    </ol>
                </div><!-- End .container -->
            </nav>

            <div class="container">
               <center style="margin-top: 150px;margin-bottom:150px;"><h1 style="font-family:cursive">Your order has been placed successfully.</h1></center>
            </div><!-- End .container -->
            

            <div class="mb-6"></div><!-- margin -->
        </main><!-- End .main -->
<?php
include('include/footer.php');
?>