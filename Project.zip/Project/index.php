 
<?php
session_start();
ob_start();
include('include/header.php');
?>
    <div class="home page-wrapper">
        <main>
            <div class="home-top">
                <div class="home-slider owl-carousel owl-carousel-lazy">
                    <div class="home-slide text-center" class="owl-lazy" style="background-image: url('images/slider/home_slides/arts-photography.png')">
                        <img class="owl-lazy" src="images/lazy.png" data-src="" alt="slider image">
                        <div class="home-slide-content">
                            <h2>Mental Floss</h2>
                            <a href="product.php?id=25">View product<i class="porto-icon-right"></i></a>
                        </div><!-- End .home-slide-content -->
                        <div class="home-product product-default inner-quickview">
                            <figure>
                                <a href="product.php?id=25"><img src="admin/uploads/mg1.jpg" style="height: 250px;"></a>
                                
                            </figure>
                            <div class="product-details text-center">
                                <h2 class="product-title">
                                    <a href="product.php?id=25">Mental Floss</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">$6.00</span>
                                </div>
                            </div>
                        </div>
                    </div><!-- End .home-slide -->
                    <div class="home-slide text-center" class="owl-lazy" style="background-image: url('images/slider/home_slides/business-investing.png')">
                        <img class="owl-lazy" src="images/lazy.png" data-src="" alt="slider image">
                        <div class="home-slide-content">
                            <h2>Fast Company</h2>
                            <a href="product.php?id=26">View product<i class="porto-icon-right"></i></a>
                        </div><!-- End .home-slide-content -->
                        <div class="home-product product-default inner-quickview">
                            <figure>
                                <a href="product.php?id=26"><img src="admin/uploads/mg2.jpg" style="height: 250px;"></a>
                                
                            </figure>
                            <div class="product-details text-center">
                                <h2 class="product-title">
                                    <a href="product.php?id=26">Fast Company</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">$4.00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="home-slide text-center" class="owl-lazy" style="background-image: url('images/slider/home_slides/literature-fiction.png')">
                        <img class="owl-lazy" src="images/lazy.png" data-src="" alt="slider image">
                        <div class="home-slide-content">
                            <h2>Harry Potter</h2>
                            <a href="product.php?id=12">View product<i class="porto-icon-right"></i></a>
                        </div><!-- End .home-slide-content -->
                        <div class="home-product product-default inner-quickview">
                            <figure>
                                <a href="product.php?id=12"><img src="admin/uploads/book6.jpg" style="height: 250px;"></a>
                                
                            </figure>
                            <div class="product-details text-center">
                                <h2 class="product-title">
                                    <a href="product.php?id=12">Harry Potter</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">$8.00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="home-slide text-center" class="owl-lazy" style="background-image: url('images/slider/home_slides/mystery-suspense.png')">
                        <img class="owl-lazy" src="images/lazy.png" data-src="" alt="slider image">
                        <div class="home-slide-content">
                            <h2>Sherlock Holmes</h2>
                            <a href="product.php?id=8">View product<i class="porto-icon-right"></i></a>
                        </div><!-- End .home-slide-content -->
                        <div class="home-product product-default inner-quickview">
                            <figure>
                                <a href="product.php?id=8"><img src="admin/uploads/book2.jpg" style="height: 250px;"></a>
                                
                            </figure>
                            <div class="product-details text-center">
                                <h2 class="product-title">
                                    <a href="product.php?id=8">Sherlock Holmes</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">$15.00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="home-slide text-center" class="owl-lazy" style="background-image: url('images/slider/home_slides/scifi-fantasy.png')">
                        <img class="owl-lazy" src="images/lazy.png" data-src="" alt="slider image">
                        <div class="home-slide-content">
                            <h2>Romeo and Juliet</h2>
                            <a href="product.php?id=7">View product<i class="porto-icon-right"></i></a>
                        </div><!-- End .home-slide-content -->
                        <div class="home-product product-default inner-quickview">
                            <figure>
                                <a href="product.php?id=7"><img src="admin/uploads/book1.png" style="height: 250px;"></a>
                                
                            </figure>
                            <div class="product-details text-center">
                                <h2 class="product-title">
                                    <a href="product.php?id=7">Romeo and Juliet</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">$20.00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- End .home-slider -->

            <section class="container mt-4" id="bestsellers">
                
                    <div class="section-title">
                        <h3 style="background:black;text-transform:uppercase;letter-spacing:2px;width:600px;border-radius:0px 50px 0px 50px;height:60px;color:white;font-family:cursive;line-height:60px;text-align:center;margin-left:350px">
                        Best Sellers Books And Magazines</h3>
                        <a href="#">VIEW ALL PRODUCTS<i class="porto-icon-right"></i></a>
                    </div>
                    <div class="section-content row row-sm">
                        <div class="col-md-6 col-xl-4">
                            <div class="home-banner text-center">
                                <div class="banner-content">
                                    <span>BOOK CLUB</span>
                                    <h2>A selection with <br>only the best books</h2>
                                </div>
                                <img src="admin/img/login-bg.jpg">
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-8 home-products-intro">
                            <div class="row row-sm">
                                <div class="col-6 col-sm-4 col-xl-3 home-product product-default inner-quickview">
                                    <figure>
                                        <a href="product.php?id=7"><img src="admin/uploads/book1.png" style="height: 300px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=7">Romeo and Juliet</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$20.00</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-sm-4 col-xl-3 home-product product-default inner-quickview">
                                    <figure>
                                        <a href="product.php?id=8"><img src="admin/uploads/book2.jpg" style="height: 300px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=8">Sherlock Holmes</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$15.00</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-sm-4 col-xl-3 home-product product-default inner-quickview">
                                    <figure>
                                        <a href="product.php?id=9"><img src="admin/uploads/book3.jpg" style="height: 300px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=9">Stranger in a Strange Land</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$20.00</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-sm-4 col-xl-3 home-product product-default inner-quickview">
                                    <figure>
                                        <a href="product.php?id=10"><img src="admin/uploads/book4.jpg" style="height: 300px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=10">To Kill A Mockingbird</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$16.00</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-sm-4 col-xl-3 home-product product-default inner-quickview">
                                    <figure>
                                        <a href="product.php?id=11"><img src="admin/uploads/book5.jpg" style="height: 300px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=11">Nineteen Eighty Four</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$10.00</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-sm-4 col-xl-3 home-product product-default inner-quickview">
                                    <figure>
                                        <a href="product.php?id=12"><img src="admin/uploads/book6.jpg" style="height: 300px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=12">Harry Potter</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$8.00</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-sm-4 col-xl-3 home-product product-default inner-quickview">
                                    <figure>
                                        <a href="product.php?id=25"><img src="admin/uploads/mg1.jpg" style="height: 300px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=25">Mental Floss</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$6.00</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-sm-4 col-xl-3 home-product product-default inner-quickview">
                                    <figure>
                                        <a href="product.php?id=26"><img src="admin/uploads/mg2.jpg" style="height: 300px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=26">Fast Company</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$4.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
            </section>

            <section class="bg-white pb-5" style="margin-top : 5.5rem;">
                <div class="container">
                    <div class="row row-sm category-books">
                        <div class="col-sm-4 home-banner">
                            <img src="images/banners/home-banner1.jpg">
                            <div class="banner-content">
                                <h2>DEALS IN FILES</h2>
                                <a href="files.php"><button class="btn btn-primary">VIEW COLLECTION<i class="porto-icon-right"></i></button></a>
                            </div>
                        </div>
                        <div class="col-sm-4 home-banner">
                            <img src="images/banners/home-banner2.jpg">
                            <div class="banner-content">
                                <h2>DEALS IN BOOKS</h2>
                                <a href="books.php"><button class="btn btn-primary" style="background-color : #e4314f;">VIEW COLLECTION<i class="porto-icon-right"></i></button></a>
                            </div>
                        </div>
                        <div class="col-sm-4 home-banner">
                            <img src="images/banners/home-banner3.jpg">
                            <div class="banner-content">
                                <h2>DEALS IN PAPERS</h2>
                                <a href="paper.php"><button class="btn btn-primary" style="background-color : #047490;">VIEW COLLECTION<i class="porto-icon-right"></i></button></a>
                            </div>
                        </div>
                    </div>
                    <section class="home-products-intro">
                        <div class="section-title">
                            <h3 style="background:black;text-transform:uppercase;letter-spacing:2px;width:300px;border-radius:0px 50px 0px 50px;height:60px;color:white;font-family:cursive;line-height:60px;text-align:center;margin-left:470px">
                            CDs Collection</h3>
                            <a href="CDS.php">VIEW ALL PRODUCTS<i class="porto-icon-right"></i></a>
                        </div>
                        <div class="row row-sm">
                            <div class="col-6 col-sm-4 col-lg-2">
                                <div class="home-product product-default inner-quickview" style="height: 300px;">
                                    <figure>
                                        <a href="product.php?id=13"><img src="admin/uploads/CD1.jpg" style="height: 200px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=13">Sony Readable CD</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$3.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-sm-4 col-lg-2">
                                <div class="home-product product-default inner-quickview" style="height: 300px;">
                                    <figure>
                                        <a href="product.php?id=14"><img src="admin/uploads/CD2.jpg" style="height: 200px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=14">Sony Rewriteable CD</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$3.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-sm-4 col-lg-2">
                                <div class="home-product product-default inner-quickview" style="height: 300px;">
                                    <figure>
                                        <a href="product.php?id=15"><img src="admin/uploads/CD3.jpg" style="height: 200px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div> 
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=15">Sony Rewriteable CD</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$4.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-sm-4 col-lg-2">
                                <div class="home-product product-default inner-quickview" style="height: 300px;">
                                    <figure>
                                        <a href="product.php?id=16"><img src="admin/uploads/CD4.jpg" style="height: 200px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=16">Verbatim Rewriteable CD</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$3.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-sm-4 col-lg-2">
                                <div class="home-product product-default inner-quickview" style="height: 300px;">
                                    <figure>
                                        <a href="product.php?id=17"><img src="admin/uploads/CD5.jpg" style="height: 200px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=17">Maxell Rewriteable CD</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$2.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-sm-4 col-lg-2">
                                <div class="home-product product-default inner-quickview" style="height: 300px;">
                                    <figure>
                                        <a href="product.php?id=18"><img src="admin/uploads/CD6.jpg" style="height: 200px;"></a>
                                        <div class="btn-icons">
                                            <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                        </div>
                                        
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="product.php?id=18">Staples Rewriteable CD</a>
                                        </h2>
                                        <div class="price-box">
                                            <span class="product-price">$4.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </section>

            <section class="home-banner home-banner-middle" style="margin-bottom: 4.5rem;">
                <div class="container">
                    <div class="banner-content">
                        <span>AVAILABLE ONCE A YEAR</span>
                        <h2>Get 30% off on orders over $299</h2>
                        <p>* SELECTED BOOKS</p>
                    </div>
                    <a href="books.php"><button class="btn">EXPLORE BOOKS<i class="porto-icon-right"></i></button></a>
                    <div class="banner-content" style="visibility: hidden;">
                        <span>AVAILABLE ONCE A YEAR</span>
                        <h2>Get 30% off on orders over $299</h2>
                        <p>* SELECTED BOOKS</p>
                    </div>
                </div>
            </section>

            <section class="home-products-intro container">
                <div class="section-title">
                    <h3 style="background:black;text-transform:uppercase;letter-spacing:2px;width:300px;border-radius:0px 50px 0px 50px;height:60px;color:white;font-family:cursive;line-height:60px;text-align:center;margin-left:470px">
                        Files Collection</h3>
                    <a href="files.php">VIEW ALL PRODUCTS<i class="porto-icon-right"></i></a>
                </div>
                <div class="row row-sm">
                    <div class="col-6 col-sm-4 col-lg-2">
                        <div class="home-product product-default inner-quickview" style="height: 300px;">
                            <figure>
                                <a href="product.php?id=31"><img src="admin/uploads/file1.jpg" style="height: 200px;"></a>
                                <div class="btn-icons">
                                    <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                </div>
                                
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.php?id=31">Plastic File</a>
                                </h2>
                                <div class="price-box">
                                    <span class="old-price">$2.00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-4 col-lg-2">
                        <div class="home-product product-default inner-quickview" style="height: 300px;">
                            <figure>
                                <a href="product.php?id=32"><img src="admin/uploads/file2.jpg" style="height: 200px;"></a>
                                <div class="btn-icons">
                                    <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                </div>
                                
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.php?id=32">Plastic File</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">$2.00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-4 col-lg-2">
                        <div class="home-product product-default inner-quickview" style="height: 300px;">
                            <figure>
                                <a href="product.php?id=33"><img src="admin/uploads/file3.jpg" style="height: 200px;"></a>
                                <div class="btn-icons">
                                    <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                </div>
                                
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.php?id=33">Paper File</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">$1.00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-4 col-lg-2">
                        <div class="home-product product-default inner-quickview" style="height: 300px;">
                            <figure>
                                <a href="product.php?id=34"><img src="admin/uploads/file4.jpg" style="height: 200px;"></a>
                                <div class="btn-icons">
                                    <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                </div>
                                
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.php?id=34">Cardboard File</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">$4.00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-4 col-lg-2">
                        <div class="home-product product-default inner-quickview" style="height: 300px;">
                            <figure>
                                <a href="product.php?id=35"><img src="admin/uploads/file5.jpg" style="height: 200px;"></a>
                                <div class="btn-icons">
                                    <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                </div>
                                
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.php?id=35">Paper File</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">$2.00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-4 col-lg-2">
                        <div class="home-product product-default inner-quickview" style="height: 300px;">
                            <figure>
                                <a href="product.php?id=36"><img src="admin/uploads/file6.jpg" style="height: 200px;"></a>
                                <div class="btn-icons">
                                    <button class="btn-icon btn-add-cart" data-toggle="modal" data-target="#addCartModal"><i class="porto-icon-bag-2"></i></button>
                                </div>
                                
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.php?id=36">Paper File</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">$1.00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main><!-- End .main -->

<?php
include('include/footer.php');
?>