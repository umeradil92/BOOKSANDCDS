<?php
ob_start();

session_start();

   
include('include/header.php');
include('DB_connection.php');

if(isset($_POST['next'])){
$u_id = $_SESSION['id'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$address1 = $_POST['address1'];
$address2 = $_POST['address2'];
$city = $_POST['city'];
$state = $_POST['state'];
$country = $_POST['country'];
$zipcode = $_POST['zip'];
$phoneno = $_POST['phoneno'];
$shippingm = $_POST['shipping-method'];
$total_price = 0;
$ship = 0;
}
?>
    <div class="page-wrapper">
        <main class="main">
            <nav aria-label="breadcrumb" class="breadcrumb-nav mb-2">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                    </ol>
                </div><!-- End .container -->
            </nav>

            <div class="container">
                <ul class="checkout-progress-bar">
                    <li>
                        <span>Shipping</span>
                    </li>
                    <li class="active">
                        <span>Review &amp; Payments</span>
                    </li>
                </ul>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="order-summary">
                            <h3>Summary</h3>
                            <h4>
                                <a data-toggle="collapse" href="#order-cart-section" class="collapsed" role="button" aria-expanded="false" aria-controls="order-cart-section">
                                Your products in Cart
                                </a>
                            </h4>

                            <div class="collapse" id="order-cart-section">
                                <table class="table table-mini-cart">
                                <tbody>
                                    <?php
                                    if($_SESSION['cart'] ?? null){
                                        foreach($_SESSION['cart'] as $cart){
                                    ?>
                                        <tr>
                                            <td class="product-col">
                                                <figure class="product-image-container">
                                                    <a href="product.php?id=<?php echo $cart['id']?>" class="product-image">
                                                    <img style="height: 100px;width: 100px;" src="<?php echo $cart['image'];?>" alt="product">
                                                    </a>
                                                </figure>
                                                <div>
                                                    <h2 class="product-title">
                                                        <a href="product.php?id=<?php echo $cart['id']?>"><?php echo $cart['name']?></a>
                                                    </h2>
                                                    <span class="product-qty">Qty: <?php echo $cart['quan']?></span>
                                                </div>
                                            </td>
                                            <td class="price-col">$<?php echo $cart['price'];?></td>
                                        </tr>
                                        <?php
                                        }
                                    }
                                    ?>
                                        <tr>
                                            <td>Shipping fee</td>
                                            <td class="price-col">$<?php 
                                            if($zipcode == "75300" ||  $zipcode == "75301" || $zipcode == "75302" || $zipcode == "75303" || $zipcode == "75304" || $zipcode == "75305"){
                                                echo $ship;
                                            }
                                            else{
                                                $ship =  2;
                                                echo $ship;
                                            }
                                            ?>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>Overall cost</td>
                                            <?php
                                            if(isset($_SESSION["cart"])){
                                                foreach ($_SESSION["cart"] as $product){
                                                $product_id = $product['id'];
                                                $total_price += (($product["price"]*$product['quan'])+$ship);
                                                }
                                            }
                                            else{
                                                $total_price = 0;
                                            }
                                            ?>
                                            <td class="price-col">$<?php echo $total_price;?></td>
                                        </tr>               
                            </tbody>    
                        </table>
                    </div><!-- End #order-cart-section -->
                </div><!-- End .order-summary -->

                        <div class="checkout-info-box">
                            <h3 class="step-title">Ship To:
                                <a href="javascript:history.back()" title="Edit" class="step-title-edit">
                                    <span class="sr-only">Edit</span>
                                    <i class="porto-icon-pencil"></i>
                                </a>
                            </h3>
                            <address>
                                <?php echo $fname." ".$lname?> <br>
                                <?php echo $address1." ".$address2?> <br>
                                <?php echo $state.", ".$city." ".$zipcode?> <br>
                                <?php echo $country?> <br>
                                <?php echo $phoneno?>
                            </address>
                        </div><!-- End .checkout-info-box -->
                        
                        <!--<div class="checkout-info-box">
                            <h3 class="step-title">Shipping Method: 
                                <a href="#" title="Edit" class="step-title-edit"><span class="sr-only">Edit</span><i class="porto-icon-pencil"></i></a>
                            </h3>
                            <p>Flat Rate - Fixed</p>
                        </div>--><!-- End .checkout-info-box -->
                    </div><!-- End .col-lg-4 -->
                    
                    <div class="col-lg-8 order-lg-first">
                        <div class='checkout-payment'>
                            <h2 class="step-title">Payment Method: 
                                <?php
                                if($shippingm == "cc"){
                                    echo "Credit Card";
                                }
                                elseif($shippingm == "bt"){
                                    echo "Online Transfer";
                                }
                                else{
                                    echo "Cash on Delivery";
                                }
                            ?>
                            </h2>
                            <h4>Check / Money order</h4>
                            <div class='form-group-custom-control'>
                                <!-- End .custom-checkbox -->
                            </div><!-- End .form-group -->

                            <div id='checkout-shipping-address'>
                                <address>
                                    <?php echo $fname." ".$lname?> <br>
                                    <?php echo $address1." ".$address2?> <br>
                                    <?php echo $state.", ".$city." ".$zipcode?> <br>
                                    <?php echo $country?> <br>
                                    <?php echo $phoneno?>
                                </address>
                            </div><!-- End #checkout-shipping-address -->

                            <div id='new-checkout-address' class='show'>
                                <?php
                                   if($shippingm == "cc"){
                                    echo "
                                    <form action='' method='POST'>
                                        <div class='form-group required-field'>
                                            <label>Card Number </label>
                                            <input type='text' class='form-control' name='ccnumber' pattern='[0-9]{16}' required placeholder='Card Number' >
                                        </div><!-- End .form-group -->

                                        <div class='form-group required-field'>
                                            <label>Expiry </label>
                                            <input type='text' class='form-control' name='expiry' pattern='[0-9/]{2,10}'  required placeholder='MM/YYYY' >
                                        </div><!-- End .form-group -->

                                        <div class='form-group required-field'>
                                            <label>CVV </label>
                                            <input type='password' class='form-control' name='cvv' pattern='[0-9]{3,4}' required placeholder='Enter your CVV/CVV2'  >
                                        </div><!-- End .form-group -->
                                        <div class='clearfix'>
                                        <button type='submit' name='ccsubmit' class='btn btn-primary float-right'>Place Order</button>
                                        </div>
                                    </form>";
                                    }
                                    elseif($shippingm == "bt"){
                                       echo "<br /><center><h4>Bank Details:</h4></center>";
                                       echo "<br /><center><h4>Meezan Bank : 05864539838641</h4></center>";
                                       echo "<br /><center><h4>Title : Shradha Book Store PVT</h4></center>
                                       <form action='' method='POST'>
                                            <div class='clearfix'>
                                                <button type='submit' name='ccsubmit' class='btn btn-primary float-right'>Place Order</button>
                                            </div>
                                        </form>";
                                    }
                                    else{
                                        echo "<br /><center><h4>You're good to go now</h4></center>
                                        <form action='' method='POST'>
                                            <div class='clearfix'>
                                                <button type='submit' name='ccsubmit' class='btn btn-primary float-right'>Place Order</button>
                                            </div>
                                        </form>";
                                    }
                                ?>

                                <?php 
                                    if(isset($_POST['ccsubmit'])){
                                        $ccnumber = $_POST['ccnumber'];
                                        $expiry = $_POST['expiry'];
                                        $cvv = $_POST['cvv'];
                                        $orderno = rand(00000000, 99999999);
                                        $user_id = $_SESSION['id'];
                                        $address1 = "jamshed road no.3";
                                        $address2 = "fatima jinnah colony";
                                        $city = "Karachi";
                                        $state = "Sindh";
                                        $country = "Pakistan";
                                        $zipcode = "75300";
                                        $phoneno = "+923162028605";
                                       
                                        if($shippingm == "cc"){
                                            $payment_method =  "Credit Card";
                                        }
                                        elseif($shippingm == "bt"){
                                            $payment_method =  "Online Transfer";
                                        }else{
                                            $payment_method =  "Cash on Delivery";
                                        }
                                        $query = mysqli_query($con,"INSERT INTO tb_checkout(`checkout_orderno`,`checkout_fk_user`,`checkout_add_country`,`checkout_add_city`,`checkout_add_street1`,`checkout_add_street2`,`chectout_add_zipcode`,`checkout_add_phoneno`,`checkout_paymentmethod`,`checkout_price`,`checkout_fk_product`) VALUES ('$orderno','$user_id','$country','$city','$address1','$address2','$zipcode','$phoneno','$payment_method','$total_price','$product_id')");
                                        if($payment_method = "Credit Card" && $query){
                                            $query_2 = mysqli_query($con,"INSERT INTO tb_onlinepayment(`onlinepayment_cardnumber`,`onlinepayment_expiry`,`onlinepayment_cvv`,`onlinepayment_fk_users`) VALUES ('$ccnumber','$expiry','$cvv','$user_id')");
                                            unset($_SESSION["cart"]);
                                            header('location:success.php');
                                        }
                                        elseif($query){
                                            unset($_SESSION["cart"]);
                                            header('location:success.php');
                                        }
                                    }
                                 ?>
                        </div><!-- End #new-checkout-address -->
                        <!-- End .clearfix -->
                        </div><!-- End .checkout-payment -->
                        <!-- End .collapse -->
                        </div><!-- End .checkout-discount -->
                    </div><!-- End .col-lg-8 -->
                </div><!-- End .row -->
            </div><!-- End .container -->
            <div class="mb-6"></div><!-- margin -->
        </main>     
<?php
include('include/footer.php');
?>