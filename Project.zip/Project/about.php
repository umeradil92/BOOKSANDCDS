<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .about-heading{
            font-family:cursive;
            letter-spacing:20px;
            height:100px;
            line-height:100px;
            transition-duration:1s;
        }
        .about-heading:hover{
            filter:blur(1.6px);
            font-family:cursive;
            margin-left:350px;
            padding-left:20px;
            background:rgba(0,0,0,0.9);
            height:100px;
            line-height:100px;
            overflow:hidden;
        }
    </style>
</head>
<body>
<?php
include('include/header.php');
?>
    <div class="page-wrapper">
        <main class="main">
            <div class="page-header page-header-bg" style="background-image: url('images/banners/about-banner.jpg');">
                <div class="container">
                    <h1 class="about-heading">About Us</h1>
                </div><!-- End .container -->
            </div><!-- End .page-header -->

            <nav aria-label="breadcrumb" class="breadcrumb-nav">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php" style="font-family:cursive">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page" style="font-family:cursive">About Us</li>
                    </ol>
                </div><!-- End .container -->
            </nav>

            <div class="about-section">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-7">
                            <h2 class="subtitle" style="font-family:cursive">OUR HISTORY</h2>
                            <p>We sell different types of books of different publications of stories, school related text books, note books, essay writing books, some of books for the competitions like General Knowledge, Essay Writing, and also novels, books to improve vocabulary, for learning other languages,etc and also we sell some of the book related materials like covers, pens, pencils, Files, etc.</p>
                        </div><!-- End .col-lg-7 -->

                        <div class="col-lg-5">
                            <h2 class="subtitle" style="font-family:cursive">CLIENT REVIEWS</h2>

                            <div class="testimonials-slider owl-carousel owl-theme" data-toggle="owl" data-owl-options="{
                                'items': 1,
                                'dots': true
                            }">
                                <div class="testimonial">
                                    <div class="testimonial-owner">
                                        <figure>
                                            <img src="images/clients/client1.png" alt="client">
                                        </figure>

                                        <div>
                                            <h4 class="testimonial-title">Agha Ali</h4>
                                        </div>
                                    </div><!-- End .testimonial-owner -->

                                    <blockquote>
                                        <p>Great experience order was the same as shown in pictures.</p>
                                    </blockquote>
                                </div><!-- End .testimonial -->

                                <div class="testimonial">
                                    <div class="testimonial-owner">
                                        <figure>
                                            <img src="images/clients/client2.png" alt="client">
                                        </figure>

                                        <div>
                                            <h4 class="testimonial-title">Suleman</h4>
                                        </div>
                                    </div><!-- End .testimonial-owner -->

                                    <blockquote>
                                        <p>Very cooperative company order was delivered on time and prices are good as compared to market.</p>
                                    </blockquote>
                                </div><!-- End .testimonial -->
                            </div><!-- End .testimonials-slider -->
                        </div><!-- End .col-lg-5 -->
                    </div><!-- End .row -->
                </div><!-- End .container -->
            </div><!-- End .about-section -->

            <div class="gallery-section popup-gallery">
                <div class="container">
                    <h2 class="subtitle" style="font-family:cursive">PHOTO GALLERY</h2>
                    <div class="owl-carousel owl-theme text-center" data-toggle="owl" data-owl-options="{
                        'dots': true,
                        'margin': 20,
                        'responsive': {
                            '0': {
                                'items': 1
                            },
                            '500': {
                                'items': 2
                            },
                            '768': {
                                'items': 3
                            },
                            '992': {
                                'items': 4
                            }
                        }
                    }">
                        <a href="images/about/gallery-1.jpg" class="gallery-item">
                            <img src="images/about/gallery-1.jpg" alt="gallery image" style="height: 200px;">
                        </a>
                        <a href="images/about/gallery-2.jpg" class="gallery-item">
                            <img src="images/about/gallery-2.jpg" alt="gallery image" style="height: 200px;">
                        </a>
                        <a href="images/about/gallery-3.jpg" class="gallery-item">
                            <img src="images/about/gallery-3.jpg" alt="gallery image" style="height: 200px;">
                        </a>
                        <a href="images/about/gallery-4.jpg" class="gallery-item">
                            <img src="images/about/gallery-4.jpg" alt="gallery image" style="height: 200px;">
                        </a>
                    </div>
                    
                </div><!-- End .container -->
            </div><!-- End .gallery-section -->

            <div class="company-section">
                <div class="container">
                    <div class="row align-items-lg-center">
                        <div class="col-md-6">
                            <img src="images/about/img1.jpg" alt="image">
                        </div><!-- End .col-lg-6 -->

                        <div class="col-md-6 padding-left-lg">
                            <h3 class="subtitle" style="font-family:cursive">OUR MISSION</h3>
                            <p>Our mission is to provide our clients with best quality products.</p>

                            <h3 class="subtitle" style="font-family:cursive">OUR VISION</h3>
                            <p>To provide our customers with absolutely best quality products without any hastle at your doorsteps.</p>
                        </div><!-- End .col-lg-6 -->
                    </div><!-- End .row -->
                </div><!-- End .container -->
            </div><!-- End .company-section -->

            <div class="features-section">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="feature-box">
                                <i class="porto-icon-shipped"></i>

                                <div class="feature-box-content">
                                    <h3 style="font-family:cursive">FREE SHIPPING</h3>
                                    <p>Free shipping on orders less than 3 kms.</p>
                                </div><!-- End .feature-box-content -->
                            </div><!-- End .feature-box -->
                        </div><!-- End .col-md-4 -->
                        
                        <div class="col-md-4">
                            <div class="feature-box">
                                <i class="porto-icon-us-dollar"></i>

                                <div class="feature-box-content">
                                    <h3 style="font-family:cursive">100% MONEY BACK GUARANTEE</h3>
                                    <p>Money back guarantee if product is not delivered on time.</p>
                                </div><!-- End .feature-box-content -->
                            </div><!-- End .feature-box -->
                        </div><!-- End .col-md-4 -->

                        <div class="col-md-4">
                            <div class="feature-box">
                                <i class="porto-icon-online-support"></i>

                                <div class="feature-box-content">
                                    <h3 style="font-family:cursive">ONLINE SUPPORT 24/7</h3>
                                    <p>24/7 technical support from our expert technicians.</p>
                                </div><!-- End .feature-box-content -->
                            </div><!-- End .feature-box -->
                        </div><!-- End .col-md-4 -->
                    </div><!-- End .row -->
                </div><!-- End .container -->
            </div><!-- End .features-section -->
        </main><!-- End .main -->
<?php
include('include/footer.php');
?>
</body>
</html>