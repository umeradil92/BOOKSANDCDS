<?php
include('DB_connection.php');
include('include/header.php');
?>
    <link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <style type="text/css">
        .faq{
            width: 50%;
            border: 10px solid silver;
            border-radius:10px;
        }
        .faqitem .header{
            padding: 15px;
            background: yellow;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
        }
        .faqitem .header h4{
            margin: 0;
        }
        .faqitem .header .fa.fa-minus{
            display: none;
        }
        .faqitem.jquery-accordion-active .fa.fa-minus{
            display: block;
        }
        .faqitem.jquery-accordion-active .fa.fa-plus{
            display: none;
        }
        .faqitem .content{
            padding: 15px;
            display: none;
        }
        .container h1:hover{
            color:Red;
            text-shadow:15px 15px 10px black;
        }
	</style>
    <div class="container" style="margin-bottom: 150px;">
        <h1 style="margin-top: 150px;font-family:cursive;transition-duration:0.8s;width:680px;">Frequently Asked Questions</h1>
        <div id="carbon-block" style="margin:30px auto"></div>
        <?php 
            $query=mysqli_query($con,"SELECT * FROM tb_faq");
            $i=0;
            while ($fetch = mysqli_fetch_array($query))
            {
                $i++;
        ?>
        <div class="faq">
            <div class="faqitem">
                <div class="header">
                    <h4 style="font-family:cursive;font-weight:bold;letter-spacing:1px;"><?php echo $i.".   ".$fetch['faq_ques']?></h4>
                    <i class="fa fa-plus"></i>
                    <i class="fa fa-minus"></i>
                </div>
                <div class="content"><?php echo $fetch['faq_ans']?></div>
            </div>
        </div>
        <?php 
            }
        ?>
        <img src="images/faq-side.png" style="position:absolute;z-index:1;margin-top:-500px;margin-left:850px;width:600px;height:400px;">
    </div>
<?php
include('include/footer.php');
?>